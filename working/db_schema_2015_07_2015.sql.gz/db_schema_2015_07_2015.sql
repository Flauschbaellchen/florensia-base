-- phpMyAdmin SQL Dump
-- version 3.3.7deb8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 05, 2015 at 10:23 PM
-- Server version: 1.0.20
-- PHP Version: 5.3.3-7+squeeze26

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `florensia`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache_character`
--

CREATE TABLE IF NOT EXISTS `cache_character` (
  `charactername` varchar(13) NOT NULL,
  `vcard` text NOT NULL,
  `savetime` int(11) NOT NULL,
  PRIMARY KEY (`charactername`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cache_main`
--

CREATE TABLE IF NOT EXISTS `cache_main` (
  `cacheid` varchar(100) CHARACTER SET utf8 NOT NULL,
  `cachedata` text CHARACTER SET utf8 NOT NULL,
  `lastchanged` int(11) NOT NULL,
  PRIMARY KEY (`cacheid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_addition`
--

CREATE TABLE IF NOT EXISTS `flobase_addition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(12) NOT NULL,
  `classid` varchar(16) NOT NULL,
  `entrystatus` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `entry` (`class`,`classid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1343 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character`
--

CREATE TABLE IF NOT EXISTS `flobase_character` (
  `characterid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `charname` varchar(14) NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL DEFAULT '0',
  `preupdate` int(10) unsigned NOT NULL DEFAULT '0',
  `updatepriority` tinyint(3) unsigned NOT NULL DEFAULT '20',
  `forceupdate` tinyint(4) NOT NULL DEFAULT '0',
  `firsterror` int(10) unsigned NOT NULL,
  PRIMARY KEY (`characterid`),
  UNIQUE KEY `charname` (`charname`),
  KEY `lastupdate` (`lastupdate`),
  KEY `forceupdate` (`forceupdate`),
  KEY `updatepriority` (`updatepriority`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2000440 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character_archiv`
--

CREATE TABLE IF NOT EXISTS `flobase_character_archiv` (
  `characterid` int(10) unsigned NOT NULL,
  `charname` varchar(14) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` varchar(255) NOT NULL,
  PRIMARY KEY (`characterid`),
  KEY `charname` (`charname`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character_data`
--

CREATE TABLE IF NOT EXISTS `flobase_character_data` (
  `characterid` int(10) unsigned NOT NULL,
  `server` varchar(16) NOT NULL,
  `jobclass` varchar(32) NOT NULL,
  `levelsum` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `levelland` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `levelsea` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guildid` int(11) unsigned NOT NULL DEFAULT '0',
  `guild` varchar(13) NOT NULL,
  `guildgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gender` char(1) NOT NULL,
  `xmlhash` char(32) NOT NULL,
  `firstappearance` int(10) unsigned NOT NULL,
  `avatar_size` varchar(7) NOT NULL,
  `priv_log_guild` varchar(3) NOT NULL,
  `priv_log_level` varchar(3) NOT NULL,
  `priv_friends` varchar(3) NOT NULL,
  `handle_friends` char(1) NOT NULL,
  `ownerid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`characterid`),
  KEY `levelsea` (`levelsea`),
  KEY `levelland` (`levelland`),
  KEY `jobclass` (`jobclass`),
  KEY `guild` (`guild`),
  KEY `levelsum` (`levelsum`),
  KEY `server` (`server`),
  KEY `gender` (`gender`),
  KEY `guildid` (`guildid`),
  KEY `guildgrade` (`guildgrade`),
  KEY `priv_log_guild` (`priv_log_guild`),
  KEY `priv_log_level` (`priv_log_level`),
  KEY `priv_friends` (`priv_friends`),
  KEY `ownerid` (`ownerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character_gallery`
--

CREATE TABLE IF NOT EXISTS `flobase_character_gallery` (
  `characterid` int(10) unsigned NOT NULL DEFAULT '0',
  `galleryid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`characterid`,`galleryid`),
  KEY `galleryid` (`galleryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character_log_banned`
--

CREATE TABLE IF NOT EXISTS `flobase_character_log_banned` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `characterid` int(10) unsigned NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `endtime` (`endtime`),
  KEY `characterid` (`characterid`),
  KEY `starttime` (`starttime`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=77551 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character_log_general`
--

CREATE TABLE IF NOT EXISTS `flobase_character_log_general` (
  `characterid` int(10) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `preupdate` int(10) unsigned NOT NULL DEFAULT '0',
  `attribute` varchar(32) NOT NULL,
  `oldvalue` varchar(32) NOT NULL,
  `newvalue` varchar(32) NOT NULL,
  KEY `characterid` (`characterid`),
  KEY `timestamp` (`timestamp`),
  KEY `attribute` (`attribute`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character_log_guild`
--

CREATE TABLE IF NOT EXISTS `flobase_character_log_guild` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `characterid` int(10) unsigned NOT NULL,
  `action` char(1) NOT NULL,
  `guildid` int(10) unsigned NOT NULL,
  `oldguildgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `newguildgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `pretimestamp` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `guildid` (`guildid`),
  KEY `timeline1` (`timestamp`),
  KEY `characterid` (`characterid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=823272 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character_log_level_land`
--

CREATE TABLE IF NOT EXISTS `flobase_character_log_level_land` (
  `characterid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `preupdate` int(10) unsigned NOT NULL DEFAULT '0',
  `prelevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pretimestamp` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`characterid`,`level`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character_log_level_sea`
--

CREATE TABLE IF NOT EXISTS `flobase_character_log_level_sea` (
  `characterid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `preupdate` int(10) unsigned NOT NULL DEFAULT '0',
  `prelevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pretimestamp` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`characterid`,`level`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character_ranking_global`
--

CREATE TABLE IF NOT EXISTS `flobase_character_ranking_global` (
  `type` char(1) NOT NULL,
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  `lastupdated` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`type`,`level`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character_ranking_local`
--

CREATE TABLE IF NOT EXISTS `flobase_character_ranking_local` (
  `type` char(1) NOT NULL,
  `server` varchar(16) NOT NULL,
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  `lastupdated` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`type`,`server`,`level`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_character_verification`
--

CREATE TABLE IF NOT EXISTS `flobase_character_verification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `characterid` int(10) unsigned NOT NULL,
  `timestamp` int(11) NOT NULL,
  `accepted` tinyint(4) NOT NULL DEFAULT '-1',
  `moderated` varchar(32) NOT NULL,
  `comment` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `done` (`accepted`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3216 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_class_columns`
--

CREATE TABLE IF NOT EXISTS `flobase_class_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_korean` text NOT NULL,
  `code_english` text NOT NULL,
  `name` text NOT NULL,
  `vieworder` int(11) NOT NULL DEFAULT '100',
  `secret` smallint(1) NOT NULL DEFAULT '1',
  `name_en` varchar(64) NOT NULL,
  `name_de` varchar(64) NOT NULL,
  `name_fr` varchar(64) NOT NULL,
  `name_it` varchar(64) NOT NULL,
  `name_es` varchar(64) NOT NULL,
  `name_pt` varchar(64) NOT NULL,
  `name_tr` varchar(64) NOT NULL,
  `name_pl` varchar(64) NOT NULL,
  `name_ru` varchar(64) NOT NULL,
  `name_nl` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_defaults`
--

CREATE TABLE IF NOT EXISTS `flobase_defaults` (
  `title` varchar(32) NOT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_donate_donators`
--

CREATE TABLE IF NOT EXISTS `flobase_donate_donators` (
  `timestamp` int(10) unsigned NOT NULL,
  `name` varchar(32) NOT NULL,
  `amount` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`timestamp`),
  KEY `amount` (`amount`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_donate_goals`
--

CREATE TABLE IF NOT EXISTS `flobase_donate_goals` (
  `starttime` int(10) unsigned NOT NULL,
  `goal` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`starttime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_download`
--

CREATE TABLE IF NOT EXISTS `flobase_download` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filesource` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `filesize` int(11) unsigned NOT NULL DEFAULT '0',
  `outgo` int(11) unsigned NOT NULL DEFAULT '0',
  `outmax` int(11) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_droplist`
--

CREATE TABLE IF NOT EXISTS `flobase_droplist` (
  `dropid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemid` varchar(9) NOT NULL,
  `npcid` varchar(9) NOT NULL,
  `thumpsup` smallint(5) unsigned NOT NULL DEFAULT '0',
  `thumpsdown` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`dropid`),
  UNIQUE KEY `dropentry` (`itemid`,`npcid`),
  KEY `npcid` (`npcid`),
  KEY `thumpsup` (`thumpsup`),
  KEY `thumpsdown` (`thumpsdown`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=18627 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_droplist_gelt`
--

CREATE TABLE IF NOT EXISTS `flobase_droplist_gelt` (
  `npcid` varchar(9) CHARACTER SET latin1 NOT NULL,
  `gelt` int(10) unsigned NOT NULL,
  `userid` int(10) unsigned NOT NULL,
  `timestamp` int(10) unsigned NOT NULL,
  KEY `npcid` (`npcid`),
  KEY `gelt` (`gelt`),
  KEY `userid` (`userid`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_droplist_quest`
--

CREATE TABLE IF NOT EXISTS `flobase_droplist_quest` (
  `dropid` int(10) unsigned NOT NULL,
  `questid` varchar(9) CHARACTER SET latin1 NOT NULL,
  `droprate` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`dropid`,`questid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_droplist_ratings`
--

CREATE TABLE IF NOT EXISTS `flobase_droplist_ratings` (
  `dropid` int(10) unsigned NOT NULL,
  `userid` int(10) unsigned NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL,
  PRIMARY KEY (`dropid`,`userid`),
  KEY `userid` (`userid`),
  KEY `rating` (`rating`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_droplist_verified`
--

CREATE TABLE IF NOT EXISTS `flobase_droplist_verified` (
  `dropid` int(10) unsigned NOT NULL,
  `userid` int(10) unsigned NOT NULL,
  `timestamp` int(10) unsigned NOT NULL,
  PRIMARY KEY (`dropid`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_gallery`
--

CREATE TABLE IF NOT EXISTS `flobase_gallery` (
  `galleryid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `imagetype` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `filehash` char(64) NOT NULL,
  `views` int(11) unsigned NOT NULL DEFAULT '0',
  `fullviews` int(10) unsigned NOT NULL DEFAULT '0',
  `width` smallint(6) unsigned NOT NULL DEFAULT '0',
  `height` smallint(6) unsigned NOT NULL DEFAULT '0',
  `twidth` smallint(6) unsigned NOT NULL DEFAULT '0',
  `theight` smallint(6) unsigned NOT NULL DEFAULT '0',
  `filesize` int(11) unsigned NOT NULL DEFAULT '0',
  `voting` char(1) NOT NULL DEFAULT '1',
  `commenting` char(1) NOT NULL DEFAULT '1',
  `editing` char(1) NOT NULL DEFAULT '0',
  `thumpsup` int(11) unsigned NOT NULL DEFAULT '0',
  `thumpsdown` int(11) unsigned NOT NULL DEFAULT '0',
  `userlist` text NOT NULL,
  `server` varchar(32) NOT NULL,
  `tags` text NOT NULL,
  `pflags` varchar(8) NOT NULL DEFAULT 'a',
  `pusers` text NOT NULL,
  PRIMARY KEY (`galleryid`),
  UNIQUE KEY `filehash` (`filehash`),
  KEY `timestamp` (`timestamp`),
  KEY `userid` (`userid`),
  KEY `thumpsup` (`thumpsup`),
  KEY `thumpsdown` (`thumpsdown`),
  KEY `commenting` (`commenting`),
  KEY `fullviews` (`fullviews`),
  KEY `views` (`views`),
  FULLTEXT KEY `tags` (`tags`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6602 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_guides`
--

CREATE TABLE IF NOT EXISTS `flobase_guides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categories` text NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `timeline` int(11) NOT NULL,
  `language` varchar(4) NOT NULL,
  `linktype` varchar(32) NOT NULL,
  `linkvar` varchar(255) NOT NULL,
  `thumpsup` int(11) NOT NULL DEFAULT '0',
  `thumpsdown` int(11) NOT NULL DEFAULT '0',
  `userlist` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `thumpsup` (`thumpsup`),
  KEY `thumpsdown` (`thumpsdown`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_guides_categories`
--

CREATE TABLE IF NOT EXISTS `flobase_guides_categories` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `sortorder` varchar(2) NOT NULL DEFAULT '99',
  `name_en` varchar(255) NOT NULL,
  `name_de` varchar(255) NOT NULL,
  `name_fr` varchar(255) NOT NULL,
  `name_it` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  `name_pt` varchar(255) NOT NULL,
  `name_tr` varchar(255) NOT NULL,
  `name_pl` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_nl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_guild`
--

CREATE TABLE IF NOT EXISTS `flobase_guild` (
  `guildid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guildname` varchar(13) NOT NULL,
  `server` varchar(32) NOT NULL,
  `firstappearance` int(10) unsigned NOT NULL,
  `lastappearance` int(10) unsigned NOT NULL DEFAULT '0',
  `averagelevel` decimal(7,4) unsigned NOT NULL DEFAULT '0.0000',
  `averagelandlevel` decimal(7,4) unsigned NOT NULL DEFAULT '0.0000',
  `averagesealevel` decimal(7,4) unsigned NOT NULL DEFAULT '0.0000',
  `memberamount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `maxmember` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `maxmembertimestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `forceupdate` tinyint(1) unsigned NOT NULL,
  `settings_accesslevel` tinyint(3) unsigned NOT NULL DEFAULT '5',
  `priv_memberlist` char(1) NOT NULL,
  `priv_activity_guild` char(1) NOT NULL,
  `priv_activity_player` char(1) NOT NULL,
  `avatar_size` varchar(7) NOT NULL,
  `misc_wanted_age` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `misc_wanted_secondcharacter` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `misc_description` text NOT NULL,
  `misc_language` char(2) NOT NULL,
  PRIMARY KEY (`guildid`),
  KEY `server` (`server`),
  KEY `averagelandlevel` (`averagelandlevel`),
  KEY `averagesealevel` (`averagesealevel`),
  KEY `memberamount` (`memberamount`),
  KEY `needupdate` (`forceupdate`),
  KEY `guildname` (`guildname`),
  KEY `averagelevel` (`averagelevel`),
  KEY `priv_memberlist` (`priv_memberlist`),
  KEY `misc_wanted_age` (`misc_wanted_age`),
  KEY `misc_wanted_secondcharacter` (`misc_wanted_secondcharacter`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20152 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_guild_contacts`
--

CREATE TABLE IF NOT EXISTS `flobase_guild_contacts` (
  `guildid` int(10) unsigned NOT NULL,
  `contactid` tinyint(3) unsigned NOT NULL,
  `contacttype` varchar(32) NOT NULL,
  `contactvalue` varchar(255) NOT NULL,
  `contactpassword` varchar(32) NOT NULL,
  `contactprivacy` char(1) NOT NULL,
  PRIMARY KEY (`guildid`,`contactid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_guild_gallery`
--

CREATE TABLE IF NOT EXISTS `flobase_guild_gallery` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `galleryid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`galleryid`),
  KEY `galleryid` (`galleryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_guild_log_general`
--

CREATE TABLE IF NOT EXISTS `flobase_guild_log_general` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guildid` int(10) unsigned NOT NULL,
  `timestamp` int(10) unsigned NOT NULL,
  `attribute` varchar(32) NOT NULL,
  `oldvalue` varchar(32) NOT NULL,
  `newvalue` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute` (`attribute`),
  KEY `timestamp` (`timestamp`),
  KEY `guildid` (`guildid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3457059 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_guild_wanted`
--

CREATE TABLE IF NOT EXISTS `flobase_guild_wanted` (
  `guildid` int(10) unsigned NOT NULL,
  `searchid` tinyint(3) unsigned NOT NULL,
  `searchclass` varchar(32) NOT NULL,
  `level_land` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level_sea` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(10) unsigned NOT NULL,
  PRIMARY KEY (`guildid`,`searchid`,`searchclass`),
  KEY `level_land` (`level_land`),
  KEY `level_sea` (`level_sea`),
  KEY `timestamp` (`timestamp`),
  KEY `searchclass` (`searchclass`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_item_categories`
--

CREATE TABLE IF NOT EXISTS `flobase_item_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_table` varchar(32) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `itemcount` int(11) NOT NULL DEFAULT '0',
  `vieworder` smallint(6) NOT NULL DEFAULT '100',
  `orderby_lvlland` smallint(1) NOT NULL DEFAULT '0',
  `orderby_lvlsea` smallint(1) NOT NULL DEFAULT '0',
  `selectby_landclasses` smallint(1) NOT NULL DEFAULT '0',
  `selectby_seaclasses` smallint(1) NOT NULL DEFAULT '0',
  `selectby_itemtype` varchar(20) DEFAULT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_de` varchar(255) NOT NULL,
  `name_fr` varchar(255) NOT NULL,
  `name_it` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  `name_pt` varchar(255) NOT NULL,
  `name_tr` varchar(255) NOT NULL,
  `name_pl` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_nl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_table` (`name_table`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=68 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_item_columns`
--

CREATE TABLE IF NOT EXISTS `flobase_item_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_korean` varchar(255) NOT NULL,
  `code_english` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `vieworder` int(11) NOT NULL DEFAULT '100',
  `secret` smallint(1) NOT NULL DEFAULT '1',
  `defaultvalue` varchar(12) DEFAULT NULL,
  `floatvalue` smallint(1) NOT NULL DEFAULT '0',
  `endvalue` varchar(8) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_de` varchar(255) NOT NULL,
  `name_fr` varchar(255) NOT NULL,
  `name_it` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  `name_pt` varchar(255) NOT NULL,
  `name_tr` varchar(255) NOT NULL,
  `name_pl` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_nl` varchar(255) NOT NULL,
  PRIMARY KEY (`code_korean`),
  UNIQUE KEY `id` (`id`),
  KEY `code_english` (`code_english`),
  KEY `secret` (`secret`),
  KEY `vieworder` (`vieworder`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=495 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_item_effect`
--

CREATE TABLE IF NOT EXISTS `flobase_item_effect` (
  `effectid` int(11) NOT NULL,
  `korean_name` varchar(255) NOT NULL,
  `code_operator` varchar(1) NOT NULL,
  `end_operator` varchar(1) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_de` varchar(255) NOT NULL,
  `name_fr` varchar(255) NOT NULL,
  `name_it` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  `name_pt` varchar(255) NOT NULL,
  `name_tr` varchar(255) NOT NULL,
  `name_pl` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_nl` varchar(255) NOT NULL,
  PRIMARY KEY (`effectid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_item_types`
--

CREATE TABLE IF NOT EXISTS `flobase_item_types` (
  `itemtypeid` varchar(1) NOT NULL,
  `name` varchar(30) NOT NULL,
  `name_en` varchar(64) NOT NULL,
  `name_de` varchar(64) NOT NULL,
  `name_fr` varchar(64) NOT NULL,
  `name_it` varchar(64) NOT NULL,
  `name_es` varchar(64) NOT NULL,
  `name_pt` varchar(64) NOT NULL,
  `name_tr` varchar(64) NOT NULL,
  `name_pl` varchar(64) NOT NULL,
  `name_ru` varchar(64) NOT NULL,
  `name_nl` varchar(64) NOT NULL,
  PRIMARY KEY (`itemtypeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_landclass`
--

CREATE TABLE IF NOT EXISTS `flobase_landclass` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `classid` char(6) NOT NULL,
  `skilltree` varchar(255) NOT NULL,
  `rectinfolist` varchar(30) NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_de` varchar(255) NOT NULL,
  `name_fr` varchar(255) NOT NULL,
  `name_it` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  `name_pt` varchar(255) NOT NULL,
  `name_tr` varchar(255) NOT NULL,
  `name_pl` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_nl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `classid` (`classid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_language`
--

CREATE TABLE IF NOT EXISTS `flobase_language` (
  `languageid` varchar(2) NOT NULL,
  `flagid` varchar(2) NOT NULL,
  `languagename` varchar(30) NOT NULL,
  `visible_flag` varchar(1) NOT NULL DEFAULT '0',
  `visible_usernotes` varchar(1) NOT NULL DEFAULT '0',
  `visible_usermarket` varchar(1) NOT NULL DEFAULT '0',
  `prefered_stringtablelang` varchar(10) NOT NULL,
  `prefered_questtextlang` varchar(10) NOT NULL,
  `author` varchar(30) NOT NULL,
  `startpage` varchar(255) NOT NULL,
  `guides` smallint(6) NOT NULL DEFAULT '0',
  `ircchannel` varchar(30) NOT NULL,
  PRIMARY KEY (`languageid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_languagefiles`
--

CREATE TABLE IF NOT EXISTS `flobase_languagefiles` (
  `varname` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `lang_de` text NOT NULL,
  `lang_de_flag` tinyint(1) NOT NULL DEFAULT '1',
  `lang_en` text NOT NULL,
  `lang_en_flag` tinyint(1) NOT NULL DEFAULT '1',
  `lang_fr` text NOT NULL,
  `lang_fr_flag` tinyint(1) NOT NULL DEFAULT '1',
  `lang_es` text NOT NULL,
  `lang_es_flag` tinyint(1) NOT NULL DEFAULT '1',
  `lang_pt` text NOT NULL,
  `lang_pt_flag` tinyint(1) NOT NULL DEFAULT '1',
  `lang_tr` text NOT NULL,
  `lang_tr_flag` tinyint(1) NOT NULL DEFAULT '1',
  `lang_it` text NOT NULL,
  `lang_it_flag` tinyint(1) NOT NULL DEFAULT '1',
  `lang_pl` text NOT NULL,
  `lang_pl_flag` tinyint(1) NOT NULL DEFAULT '1',
  `lang_ru` text NOT NULL,
  `lang_ru_flag` tinyint(1) NOT NULL DEFAULT '1',
  `lang_nl` text NOT NULL,
  `lang_nl_flag` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`varname`),
  KEY `filename` (`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_log`
--

CREATE TABLE IF NOT EXISTS `flobase_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `currentuser` int(11) NOT NULL,
  `currentip` varchar(50) NOT NULL,
  `flagged` tinyint(1) NOT NULL DEFAULT '0',
  `logvalue` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=63369 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_log_irc`
--

CREATE TABLE IF NOT EXISTS `flobase_log_irc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(16) NOT NULL,
  `nickname` varchar(32) NOT NULL,
  `channel` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `timestamp` (`timestamp`),
  KEY `userid` (`userid`),
  KEY `nickname` (`nickname`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=104770 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_menubar`
--

CREATE TABLE IF NOT EXISTS `flobase_menubar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classname` varchar(32) NOT NULL DEFAULT 'menubar',
  `section` varchar(1) NOT NULL DEFAULT '0',
  `standalone` varchar(1) NOT NULL DEFAULT '0',
  `permission` text NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_de` varchar(255) NOT NULL,
  `name_fr` varchar(255) NOT NULL,
  `name_it` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  `name_pt` varchar(255) NOT NULL,
  `pagelink` varchar(255) NOT NULL,
  `sectionid` tinyint(4) NOT NULL DEFAULT '0',
  `rankid` tinyint(4) NOT NULL DEFAULT '1',
  `name_tr` varchar(255) NOT NULL,
  `name_pl` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_nl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classname` (`classname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=85 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_misc`
--

CREATE TABLE IF NOT EXISTS `flobase_misc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `languageid` varchar(2) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `link` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=51 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_misc_columns`
--

CREATE TABLE IF NOT EXISTS `flobase_misc_columns` (
  `code_korean` varchar(100) NOT NULL DEFAULT '',
  `code_english` varchar(100) NOT NULL,
  PRIMARY KEY (`code_korean`),
  UNIQUE KEY `english` (`code_english`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_npc_columns`
--

CREATE TABLE IF NOT EXISTS `flobase_npc_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_korean` varchar(64) NOT NULL,
  `code_english` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `vieworder` int(11) NOT NULL DEFAULT '100',
  `secret` smallint(1) NOT NULL DEFAULT '1',
  `defaultvalue` varchar(12) DEFAULT NULL,
  `floatvalue` smallint(1) NOT NULL DEFAULT '0',
  `endvalue` varchar(8) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_de` varchar(255) NOT NULL,
  `name_fr` varchar(255) NOT NULL,
  `name_it` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  `name_pt` varchar(255) NOT NULL,
  `name_tr` varchar(255) NOT NULL,
  `name_pl` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_nl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `korean` (`code_korean`),
  KEY `code_english` (`code_english`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=86 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_npc_coordinates`
--

CREATE TABLE IF NOT EXISTS `flobase_npc_coordinates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `npcid` varchar(9) NOT NULL,
  `mapid` varchar(16) NOT NULL,
  `coordinates` text NOT NULL,
  `contributed` text NOT NULL,
  `lastchange` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `npcid_mapid` (`npcid`,`mapid`),
  KEY `npcid` (`npcid`),
  KEY `mapid` (`mapid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=829 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_seaclass`
--

CREATE TABLE IF NOT EXISTS `flobase_seaclass` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `classid` char(6) NOT NULL,
  `name` varchar(64) NOT NULL,
  `name_en` varchar(64) NOT NULL,
  `name_de` varchar(64) NOT NULL,
  `name_fr` varchar(64) NOT NULL,
  `name_it` varchar(64) NOT NULL,
  `name_es` varchar(64) NOT NULL,
  `name_pt` varchar(64) NOT NULL,
  `name_tr` varchar(64) NOT NULL,
  `name_pl` varchar(64) NOT NULL,
  `name_ru` varchar(64) NOT NULL,
  `name_nl` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `classid` (`classid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_seal_optionlang`
--

CREATE TABLE IF NOT EXISTS `flobase_seal_optionlang` (
  `sealid` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_de` varchar(255) NOT NULL,
  `name_fr` varchar(255) NOT NULL,
  `name_it` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  `name_pt` varchar(255) NOT NULL,
  `name_tr` varchar(255) NOT NULL,
  `name_pl` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_nl` varchar(255) NOT NULL,
  PRIMARY KEY (`sealid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_serverlist`
--

CREATE TABLE IF NOT EXISTS `flobase_serverlist` (
  `serverid` smallint(6) NOT NULL AUTO_INCREMENT,
  `servername` varchar(32) NOT NULL,
  PRIMARY KEY (`serverid`),
  UNIQUE KEY `servername` (`servername`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_sessions`
--

CREATE TABLE IF NOT EXISTS `flobase_sessions` (
  `sessionid` varchar(32) NOT NULL,
  `lastcaptcha` int(11) NOT NULL,
  `siteimpressions` mediumint(9) NOT NULL DEFAULT '1',
  `antibot` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sessionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_signature`
--

CREATE TABLE IF NOT EXISTS `flobase_signature` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layout` varchar(255) NOT NULL,
  `template` text NOT NULL,
  `dimensions` varchar(10) NOT NULL,
  `characteramount` tinyint(2) NOT NULL,
  `author` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `characteramount` (`characteramount`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=100 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_signatureobjects`
--

CREATE TABLE IF NOT EXISTS `flobase_signatureobjects` (
  `objectname` varchar(255) NOT NULL,
  `wheretouse` text NOT NULL,
  `mandatorytags` text NOT NULL,
  `optionaltags` text NOT NULL,
  PRIMARY KEY (`objectname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_signaturetemp`
--

CREATE TABLE IF NOT EXISTS `flobase_signaturetemp` (
  `userid` int(11) NOT NULL,
  `template` text NOT NULL,
  `characters` text NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_skill_columns`
--

CREATE TABLE IF NOT EXISTS `flobase_skill_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_korean` varchar(64) NOT NULL,
  `code_english` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `vieworder` int(11) NOT NULL DEFAULT '100',
  `secret` smallint(1) NOT NULL DEFAULT '1',
  `defaultvalue` varchar(12) DEFAULT NULL,
  `floatvalue` smallint(1) NOT NULL DEFAULT '0',
  `endvalue` varchar(8) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_de` varchar(255) NOT NULL,
  `name_fr` varchar(255) NOT NULL,
  `name_it` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  `name_pt` varchar(255) NOT NULL,
  `name_tr` varchar(255) NOT NULL,
  `name_pl` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_nl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `english` (`code_english`),
  UNIQUE KEY `korean` (`code_korean`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=92 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_statistics`
--

CREATE TABLE IF NOT EXISTS `flobase_statistics` (
  `statistic` varchar(32) NOT NULL,
  `server` varchar(16) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`statistic`,`server`),
  KEY `server` (`server`),
  KEY `statistic` (`statistic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_teamspeak`
--

CREATE TABLE IF NOT EXISTS `flobase_teamspeak` (
  `guildid` int(10) unsigned NOT NULL,
  `timestamp` int(10) unsigned NOT NULL,
  `creator` int(10) unsigned NOT NULL,
  PRIMARY KEY (`guildid`),
  KEY `timestamp` (`timestamp`),
  KEY `creator` (`creator`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_user`
--

CREATE TABLE IF NOT EXISTS `flobase_user` (
  `userid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `rank` tinyint(4) NOT NULL DEFAULT '-1',
  `inactive` varchar(1) NOT NULL DEFAULT '0',
  `permissions` text NOT NULL,
  PRIMARY KEY (`userid`),
  KEY `rank` (`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_usermarket`
--

CREATE TABLE IF NOT EXISTS `flobase_usermarket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `itemid` varchar(16) NOT NULL,
  `itemamount` mediumint(9) NOT NULL DEFAULT '1',
  `exchangetype` varchar(4) NOT NULL,
  `exchange` text NOT NULL,
  `exchangegelt` int(11) NOT NULL DEFAULT '0',
  `server` varchar(32) NOT NULL,
  `characterid` int(10) unsigned NOT NULL,
  `marketlanguage` varchar(32) NOT NULL,
  `timeout` int(11) NOT NULL DEFAULT '0',
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `exchangetype` (`exchangetype`),
  KEY `itemid` (`itemid`),
  KEY `timeout` (`timeout`),
  KEY `createtime` (`createtime`),
  KEY `characterid` (`characterid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5210 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_usernotes`
--

CREATE TABLE IF NOT EXISTS `flobase_usernotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section` varchar(16) NOT NULL,
  `sectionid` varchar(16) NOT NULL,
  `userid` int(11) NOT NULL DEFAULT '0',
  `language` varchar(3) NOT NULL,
  `dateline` int(11) NOT NULL,
  `writeip` varchar(15) NOT NULL,
  `moderated` varchar(32) NOT NULL DEFAULT '0',
  `lastupdate` varchar(32) NOT NULL DEFAULT '0',
  `commenttext` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `section` (`section`),
  KEY `sectionid` (`sectionid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3089 ;

-- --------------------------------------------------------

--
-- Table structure for table `flobase_versionhistory`
--

CREATE TABLE IF NOT EXISTS `flobase_versionhistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) NOT NULL,
  `changes` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=127 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_adminlog`
--

CREATE TABLE IF NOT EXISTS `forum_adminlog` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `ipaddress` varchar(50) NOT NULL DEFAULT '',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `module` varchar(50) NOT NULL DEFAULT '',
  `action` varchar(50) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  KEY `module` (`module`,`action`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_adminoptions`
--

CREATE TABLE IF NOT EXISTS `forum_adminoptions` (
  `uid` int(10) NOT NULL DEFAULT '0',
  `cpstyle` varchar(50) NOT NULL DEFAULT '',
  `codepress` int(1) NOT NULL DEFAULT '1',
  `notes` text NOT NULL,
  `permissions` text NOT NULL,
  `defaultviews` text NOT NULL,
  `loginattempts` int(10) unsigned NOT NULL DEFAULT '0',
  `loginlockoutexpiry` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_adminsessions`
--

CREATE TABLE IF NOT EXISTS `forum_adminsessions` (
  `sid` varchar(32) NOT NULL DEFAULT '',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `loginkey` varchar(50) NOT NULL DEFAULT '',
  `ip` varchar(40) NOT NULL DEFAULT '',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `lastactive` bigint(30) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  KEY `uid` (`uid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_adminviews`
--

CREATE TABLE IF NOT EXISTS `forum_adminviews` (
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `type` varchar(6) NOT NULL DEFAULT '',
  `visibility` int(1) NOT NULL DEFAULT '0',
  `fields` text NOT NULL,
  `conditions` text NOT NULL,
  `custom_profile_fields` text NOT NULL,
  `sortby` varchar(20) NOT NULL DEFAULT '',
  `sortorder` varchar(4) NOT NULL DEFAULT '',
  `perpage` int(4) NOT NULL DEFAULT '0',
  `view_type` varchar(6) NOT NULL DEFAULT '',
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_announcements`
--

CREATE TABLE IF NOT EXISTS `forum_announcements` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fid` int(10) NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(120) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `startdate` bigint(30) NOT NULL DEFAULT '0',
  `enddate` bigint(30) NOT NULL DEFAULT '0',
  `allowhtml` int(1) NOT NULL DEFAULT '0',
  `allowmycode` int(1) NOT NULL DEFAULT '0',
  `allowsmilies` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`),
  KEY `fid` (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_attachments`
--

CREATE TABLE IF NOT EXISTS `forum_attachments` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL DEFAULT '0',
  `posthash` varchar(50) NOT NULL DEFAULT '',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(120) NOT NULL DEFAULT '',
  `filetype` varchar(120) NOT NULL DEFAULT '',
  `filesize` int(10) NOT NULL DEFAULT '0',
  `attachname` varchar(120) NOT NULL DEFAULT '',
  `downloads` int(10) unsigned NOT NULL DEFAULT '0',
  `dateuploaded` bigint(30) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  `thumbnail` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`aid`),
  KEY `posthash` (`posthash`),
  KEY `pid` (`pid`,`visible`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=129 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_attachtypes`
--

CREATE TABLE IF NOT EXISTS `forum_attachtypes` (
  `atid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `mimetype` varchar(120) NOT NULL DEFAULT '',
  `extension` varchar(10) NOT NULL DEFAULT '',
  `maxsize` int(15) NOT NULL DEFAULT '0',
  `icon` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`atid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_awaitingactivation`
--

CREATE TABLE IF NOT EXISTS `forum_awaitingactivation` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `code` varchar(100) NOT NULL DEFAULT '',
  `type` char(1) NOT NULL DEFAULT '',
  `oldgroup` bigint(30) NOT NULL DEFAULT '0',
  `misc` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16440 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_badwords`
--

CREATE TABLE IF NOT EXISTS `forum_badwords` (
  `bid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `badword` varchar(100) NOT NULL DEFAULT '',
  `replacement` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_banfilters`
--

CREATE TABLE IF NOT EXISTS `forum_banfilters` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filter` varchar(200) NOT NULL DEFAULT '',
  `type` int(1) NOT NULL DEFAULT '0',
  `lastuse` bigint(30) NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1218 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_banned`
--

CREATE TABLE IF NOT EXISTS `forum_banned` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `gid` int(10) unsigned NOT NULL DEFAULT '0',
  `oldgroup` int(10) unsigned NOT NULL DEFAULT '0',
  `oldadditionalgroups` text NOT NULL,
  `olddisplaygroup` int(11) NOT NULL DEFAULT '0',
  `admin` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `bantime` varchar(50) NOT NULL DEFAULT '',
  `lifted` bigint(30) NOT NULL DEFAULT '0',
  `reason` varchar(255) NOT NULL DEFAULT '',
  KEY `uid` (`uid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_calendarpermissions`
--

CREATE TABLE IF NOT EXISTS `forum_calendarpermissions` (
  `cid` int(10) unsigned NOT NULL DEFAULT '0',
  `gid` int(10) unsigned NOT NULL DEFAULT '0',
  `canviewcalendar` int(1) NOT NULL DEFAULT '0',
  `canaddevents` int(1) NOT NULL DEFAULT '0',
  `canbypasseventmod` int(1) NOT NULL DEFAULT '0',
  `canmoderateevents` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_calendars`
--

CREATE TABLE IF NOT EXISTS `forum_calendars` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `disporder` int(10) unsigned NOT NULL DEFAULT '0',
  `startofweek` int(1) NOT NULL DEFAULT '0',
  `showbirthdays` int(1) NOT NULL DEFAULT '0',
  `eventlimit` int(3) NOT NULL DEFAULT '0',
  `moderation` int(1) NOT NULL DEFAULT '0',
  `allowhtml` int(1) NOT NULL DEFAULT '0',
  `allowmycode` int(1) NOT NULL DEFAULT '0',
  `allowimgcode` int(1) NOT NULL DEFAULT '0',
  `allowvideocode` int(1) NOT NULL DEFAULT '0',
  `allowsmilies` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_captcha`
--

CREATE TABLE IF NOT EXISTS `forum_captcha` (
  `imagehash` varchar(32) NOT NULL DEFAULT '',
  `imagestring` varchar(8) NOT NULL DEFAULT '',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  KEY `imagehash` (`imagehash`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_datacache`
--

CREATE TABLE IF NOT EXISTS `forum_datacache` (
  `title` varchar(50) NOT NULL DEFAULT '',
  `cache` mediumtext NOT NULL,
  PRIMARY KEY (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_delayedmoderation`
--

CREATE TABLE IF NOT EXISTS `forum_delayedmoderation` (
  `did` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL DEFAULT '',
  `delaydateline` bigint(30) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `fid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tids` text NOT NULL,
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `inputs` text NOT NULL,
  PRIMARY KEY (`did`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_events`
--

CREATE TABLE IF NOT EXISTS `forum_events` (
  `eid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(120) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '0',
  `private` int(1) NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `starttime` int(10) unsigned NOT NULL DEFAULT '0',
  `endtime` int(10) unsigned NOT NULL DEFAULT '0',
  `timezone` varchar(4) NOT NULL DEFAULT '0',
  `ignoretimezone` int(1) NOT NULL DEFAULT '0',
  `usingtime` int(1) NOT NULL DEFAULT '0',
  `repeats` text NOT NULL,
  PRIMARY KEY (`eid`),
  KEY `daterange` (`starttime`,`endtime`),
  KEY `private` (`private`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_forumbans`
--

CREATE TABLE IF NOT EXISTS `forum_forumbans` (
  `bid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `fid` int(10) unsigned NOT NULL DEFAULT '0',
  `childlist` text NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`bid`),
  KEY `active` (`active`),
  KEY `uid` (`uid`),
  KEY `fid` (`fid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_forumpermissions`
--

CREATE TABLE IF NOT EXISTS `forum_forumpermissions` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fid` int(10) unsigned NOT NULL DEFAULT '0',
  `gid` int(10) unsigned NOT NULL DEFAULT '0',
  `canview` int(1) NOT NULL DEFAULT '0',
  `canviewthreads` int(1) NOT NULL DEFAULT '0',
  `canonlyviewownthreads` int(1) NOT NULL DEFAULT '0',
  `candlattachments` int(1) NOT NULL DEFAULT '0',
  `canpostthreads` int(1) NOT NULL DEFAULT '0',
  `canpostreplys` int(1) NOT NULL DEFAULT '0',
  `canpostattachments` int(1) NOT NULL DEFAULT '0',
  `canratethreads` int(1) NOT NULL DEFAULT '0',
  `caneditposts` int(1) NOT NULL DEFAULT '0',
  `candeleteposts` int(1) NOT NULL DEFAULT '0',
  `candeletethreads` int(1) NOT NULL DEFAULT '0',
  `caneditattachments` int(1) NOT NULL DEFAULT '0',
  `canpostpolls` int(1) NOT NULL DEFAULT '0',
  `canvotepolls` int(1) NOT NULL DEFAULT '0',
  `cansearch` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=400 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_forums`
--

CREATE TABLE IF NOT EXISTS `forum_forums` (
  `fid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `linkto` varchar(180) NOT NULL DEFAULT '',
  `type` char(1) NOT NULL DEFAULT '',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `parentlist` text NOT NULL,
  `disporder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `active` int(1) NOT NULL DEFAULT '0',
  `open` int(1) NOT NULL DEFAULT '0',
  `threads` int(10) unsigned NOT NULL DEFAULT '0',
  `posts` int(10) unsigned NOT NULL DEFAULT '0',
  `lastpost` int(10) unsigned NOT NULL DEFAULT '0',
  `lastposter` varchar(120) NOT NULL DEFAULT '',
  `lastposteruid` int(10) unsigned NOT NULL DEFAULT '0',
  `lastposttid` int(10) NOT NULL DEFAULT '0',
  `lastpostsubject` varchar(120) NOT NULL DEFAULT '',
  `allowhtml` int(1) NOT NULL DEFAULT '0',
  `allowmycode` int(1) NOT NULL DEFAULT '0',
  `allowsmilies` int(1) NOT NULL DEFAULT '0',
  `allowimgcode` int(1) NOT NULL DEFAULT '0',
  `allowvideocode` int(1) NOT NULL DEFAULT '0',
  `allowpicons` int(1) NOT NULL DEFAULT '0',
  `allowtratings` int(1) NOT NULL DEFAULT '0',
  `status` int(4) NOT NULL DEFAULT '1',
  `usepostcounts` int(1) NOT NULL DEFAULT '0',
  `password` varchar(50) NOT NULL DEFAULT '',
  `showinjump` int(1) NOT NULL DEFAULT '0',
  `modposts` int(1) NOT NULL DEFAULT '0',
  `modthreads` int(1) NOT NULL DEFAULT '0',
  `mod_edit_posts` int(1) NOT NULL DEFAULT '0',
  `modattachments` int(1) NOT NULL DEFAULT '0',
  `style` smallint(5) unsigned NOT NULL DEFAULT '0',
  `overridestyle` int(1) NOT NULL DEFAULT '0',
  `rulestype` smallint(1) NOT NULL DEFAULT '0',
  `rulestitle` varchar(200) NOT NULL DEFAULT '',
  `rules` text NOT NULL,
  `unapprovedthreads` int(10) unsigned NOT NULL DEFAULT '0',
  `unapprovedposts` int(10) unsigned NOT NULL DEFAULT '0',
  `defaultdatecut` smallint(4) unsigned NOT NULL DEFAULT '0',
  `defaultsortby` varchar(10) NOT NULL DEFAULT '',
  `defaultsortorder` varchar(4) NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=109 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_forumsread`
--

CREATE TABLE IF NOT EXISTS `forum_forumsread` (
  `fid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `fid` (`fid`,`uid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_forumsubscriptions`
--

CREATE TABLE IF NOT EXISTS `forum_forumsubscriptions` (
  `fsid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fsid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_groupleaders`
--

CREATE TABLE IF NOT EXISTS `forum_groupleaders` (
  `lid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `gid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `canmanagemembers` int(1) NOT NULL DEFAULT '0',
  `canmanagerequests` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_helpdocs`
--

CREATE TABLE IF NOT EXISTS `forum_helpdocs` (
  `hid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `sid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(120) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `document` text NOT NULL,
  `usetranslation` int(1) NOT NULL DEFAULT '0',
  `enabled` int(1) NOT NULL DEFAULT '0',
  `disporder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`hid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_helpsections`
--

CREATE TABLE IF NOT EXISTS `forum_helpsections` (
  `sid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `usetranslation` int(1) NOT NULL DEFAULT '0',
  `enabled` int(1) NOT NULL DEFAULT '0',
  `disporder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_icons`
--

CREATE TABLE IF NOT EXISTS `forum_icons` (
  `iid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `path` varchar(220) NOT NULL DEFAULT '',
  PRIMARY KEY (`iid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_iplogs`
--

CREATE TABLE IF NOT EXISTS `forum_iplogs` (
  `uid` int(10) NOT NULL,
  `ipaddress` varchar(50) NOT NULL,
  `dateline` bigint(30) NOT NULL,
  KEY `uid` (`uid`),
  KEY `ipaddress` (`ipaddress`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forum_joinrequests`
--

CREATE TABLE IF NOT EXISTS `forum_joinrequests` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `gid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `reason` varchar(250) NOT NULL DEFAULT '',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_mailerrors`
--

CREATE TABLE IF NOT EXISTS `forum_mailerrors` (
  `eid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `toaddress` varchar(150) NOT NULL DEFAULT '',
  `fromaddress` varchar(150) NOT NULL DEFAULT '',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `error` text NOT NULL,
  `smtperror` varchar(200) NOT NULL DEFAULT '',
  `smtpcode` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`eid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_maillogs`
--

CREATE TABLE IF NOT EXISTS `forum_maillogs` (
  `mid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `fromuid` int(10) unsigned NOT NULL DEFAULT '0',
  `fromemail` varchar(200) NOT NULL DEFAULT '',
  `touid` bigint(30) NOT NULL DEFAULT '0',
  `toemail` varchar(200) NOT NULL DEFAULT '',
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `ipaddress` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=280 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_mailqueue`
--

CREATE TABLE IF NOT EXISTS `forum_mailqueue` (
  `mid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mailto` varchar(200) NOT NULL,
  `mailfrom` varchar(200) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `headers` text NOT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1471 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_massemails`
--

CREATE TABLE IF NOT EXISTS `forum_massemails` (
  `mid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(200) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `htmlmessage` text NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `format` tinyint(1) NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `senddate` bigint(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `sentcount` int(10) unsigned NOT NULL DEFAULT '0',
  `totalcount` int(10) unsigned NOT NULL DEFAULT '0',
  `conditions` text NOT NULL,
  `perpage` smallint(4) NOT NULL DEFAULT '50',
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_moderatorlog`
--

CREATE TABLE IF NOT EXISTS `forum_moderatorlog` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `fid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `action` text NOT NULL,
  `data` text NOT NULL,
  `ipaddress` varchar(50) NOT NULL DEFAULT '',
  KEY `tid` (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_moderators`
--

CREATE TABLE IF NOT EXISTS `forum_moderators` (
  `mid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `fid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `caneditposts` int(1) NOT NULL DEFAULT '0',
  `candeleteposts` int(1) NOT NULL DEFAULT '0',
  `canviewips` int(1) NOT NULL DEFAULT '0',
  `canopenclosethreads` int(1) NOT NULL DEFAULT '0',
  `canmanagethreads` int(1) NOT NULL DEFAULT '0',
  `canmovetononmodforum` int(1) NOT NULL DEFAULT '0',
  `isgroup` int(1) unsigned NOT NULL DEFAULT '0',
  `canusecustomtools` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mid`),
  KEY `uid` (`id`,`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_modtools`
--

CREATE TABLE IF NOT EXISTS `forum_modtools` (
  `tid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `forums` text NOT NULL,
  `type` char(1) NOT NULL DEFAULT '',
  `postoptions` text NOT NULL,
  `threadoptions` text NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_mycode`
--

CREATE TABLE IF NOT EXISTS `forum_mycode` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `regex` text NOT NULL,
  `replacement` text NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  `parseorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_polls`
--

CREATE TABLE IF NOT EXISTS `forum_polls` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `question` varchar(200) NOT NULL DEFAULT '',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `options` text NOT NULL,
  `votes` text NOT NULL,
  `numoptions` smallint(5) unsigned NOT NULL DEFAULT '0',
  `numvotes` text NOT NULL,
  `timeout` bigint(30) NOT NULL DEFAULT '0',
  `closed` int(1) NOT NULL DEFAULT '0',
  `multiple` int(1) NOT NULL DEFAULT '0',
  `public` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_pollvotes`
--

CREATE TABLE IF NOT EXISTS `forum_pollvotes` (
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `voteoption` smallint(5) unsigned NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  KEY `pid` (`pid`,`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=87 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_posts`
--

CREATE TABLE IF NOT EXISTS `forum_posts` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `replyto` int(10) unsigned NOT NULL DEFAULT '0',
  `fid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(120) NOT NULL DEFAULT '',
  `icon` smallint(5) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(80) NOT NULL DEFAULT '',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `ipaddress` varchar(30) NOT NULL DEFAULT '',
  `longipaddress` int(11) NOT NULL DEFAULT '0',
  `includesig` int(1) NOT NULL DEFAULT '0',
  `smilieoff` int(1) NOT NULL DEFAULT '0',
  `edituid` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  `posthash` varchar(32) NOT NULL DEFAULT '',
  `editreason` varchar(100) NOT NULL,
  `thx` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pid`),
  KEY `tid` (`tid`,`uid`),
  KEY `uid` (`uid`),
  KEY `visible` (`visible`),
  KEY `dateline` (`dateline`),
  KEY `longipaddress` (`longipaddress`),
  FULLTEXT KEY `message` (`message`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17744 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_privatemessages`
--

CREATE TABLE IF NOT EXISTS `forum_privatemessages` (
  `pmid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `toid` int(10) unsigned NOT NULL DEFAULT '0',
  `fromid` int(10) unsigned NOT NULL DEFAULT '0',
  `recipients` text NOT NULL,
  `folder` smallint(5) unsigned NOT NULL DEFAULT '1',
  `subject` varchar(120) NOT NULL DEFAULT '',
  `icon` smallint(5) unsigned NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `deletetime` bigint(30) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `statustime` bigint(30) NOT NULL DEFAULT '0',
  `includesig` int(1) NOT NULL DEFAULT '0',
  `smilieoff` int(1) NOT NULL DEFAULT '0',
  `receipt` int(1) NOT NULL DEFAULT '0',
  `readtime` bigint(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pmid`),
  KEY `uid` (`uid`,`folder`),
  KEY `toid` (`toid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3474 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_profilefields`
--

CREATE TABLE IF NOT EXISTS `forum_profilefields` (
  `fid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `disporder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `type` text NOT NULL,
  `length` smallint(5) unsigned NOT NULL DEFAULT '0',
  `maxlength` smallint(5) unsigned NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `editable` int(1) NOT NULL DEFAULT '0',
  `hidden` int(1) NOT NULL DEFAULT '0',
  `postnum` bigint(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_promotionlogs`
--

CREATE TABLE IF NOT EXISTS `forum_promotionlogs` (
  `plid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `oldusergroup` varchar(200) NOT NULL DEFAULT '0',
  `newusergroup` smallint(6) NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `type` varchar(9) NOT NULL DEFAULT 'primary',
  PRIMARY KEY (`plid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_promotions`
--

CREATE TABLE IF NOT EXISTS `forum_promotions` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `logging` tinyint(1) NOT NULL DEFAULT '0',
  `posts` int(11) NOT NULL DEFAULT '0',
  `posttype` char(2) NOT NULL DEFAULT '',
  `registered` int(11) NOT NULL DEFAULT '0',
  `registeredtype` varchar(20) NOT NULL DEFAULT '',
  `reputations` int(11) NOT NULL DEFAULT '0',
  `reputationtype` char(2) NOT NULL DEFAULT '',
  `referrals` int(11) NOT NULL DEFAULT '0',
  `referralstype` varchar(2) NOT NULL DEFAULT '',
  `requirements` varchar(200) NOT NULL DEFAULT '',
  `originalusergroup` varchar(120) NOT NULL DEFAULT '0',
  `newusergroup` smallint(5) unsigned NOT NULL DEFAULT '0',
  `usergrouptype` varchar(120) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_reportedposts`
--

CREATE TABLE IF NOT EXISTS `forum_reportedposts` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `fid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `reportstatus` int(1) NOT NULL DEFAULT '0',
  `reason` varchar(250) NOT NULL DEFAULT '',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `fid` (`fid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_reputation`
--

CREATE TABLE IF NOT EXISTS `forum_reputation` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `adduid` int(10) unsigned NOT NULL DEFAULT '0',
  `reputation` bigint(30) NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `comments` text NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `uid` (`uid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=101 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_rss2post`
--

CREATE TABLE IF NOT EXISTS `forum_rss2post` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `forum` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `striphtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_searchlog`
--

CREATE TABLE IF NOT EXISTS `forum_searchlog` (
  `sid` varchar(32) NOT NULL DEFAULT '',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `ipaddress` varchar(120) NOT NULL DEFAULT '',
  `threads` longtext NOT NULL,
  `posts` longtext NOT NULL,
  `resulttype` varchar(10) NOT NULL DEFAULT '',
  `querycache` text NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_sessions`
--

CREATE TABLE IF NOT EXISTS `forum_sessions` (
  `sid` varchar(32) NOT NULL DEFAULT '',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(40) NOT NULL DEFAULT '',
  `time` bigint(30) NOT NULL DEFAULT '0',
  `location` varchar(150) NOT NULL DEFAULT '',
  `useragent` varchar(100) NOT NULL DEFAULT '',
  `anonymous` int(1) NOT NULL DEFAULT '0',
  `nopermission` int(1) NOT NULL DEFAULT '0',
  `location1` int(10) NOT NULL DEFAULT '0',
  `location2` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`),
  KEY `location1` (`location1`),
  KEY `location2` (`location2`),
  KEY `time` (`time`),
  KEY `uid` (`uid`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_settinggroups`
--

CREATE TABLE IF NOT EXISTS `forum_settinggroups` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `title` varchar(220) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `disporder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `isdefault` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_settings`
--

CREATE TABLE IF NOT EXISTS `forum_settings` (
  `sid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `title` varchar(120) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `optionscode` text NOT NULL,
  `value` text NOT NULL,
  `disporder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `isdefault` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=459 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_smilies`
--

CREATE TABLE IF NOT EXISTS `forum_smilies` (
  `sid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `find` varchar(120) NOT NULL DEFAULT '',
  `image` varchar(220) NOT NULL DEFAULT '',
  `disporder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `showclickable` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_spiders`
--

CREATE TABLE IF NOT EXISTS `forum_spiders` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `theme` int(10) unsigned NOT NULL DEFAULT '0',
  `language` varchar(20) NOT NULL DEFAULT '',
  `usergroup` int(10) unsigned NOT NULL DEFAULT '0',
  `useragent` varchar(200) NOT NULL DEFAULT '',
  `lastvisit` bigint(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=95 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_stats`
--

CREATE TABLE IF NOT EXISTS `forum_stats` (
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `numusers` int(10) unsigned NOT NULL DEFAULT '0',
  `numthreads` int(10) unsigned NOT NULL DEFAULT '0',
  `numposts` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`dateline`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_tasklog`
--

CREATE TABLE IF NOT EXISTS `forum_tasklog` (
  `lid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=409768 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_tasks`
--

CREATE TABLE IF NOT EXISTS `forum_tasks` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `file` varchar(30) NOT NULL DEFAULT '',
  `minute` varchar(200) NOT NULL DEFAULT '',
  `hour` varchar(200) NOT NULL DEFAULT '',
  `day` varchar(100) NOT NULL DEFAULT '',
  `month` varchar(30) NOT NULL DEFAULT '',
  `weekday` varchar(15) NOT NULL DEFAULT '',
  `nextrun` bigint(30) NOT NULL DEFAULT '0',
  `lastrun` bigint(30) NOT NULL DEFAULT '0',
  `enabled` int(1) NOT NULL DEFAULT '1',
  `logging` int(1) NOT NULL DEFAULT '0',
  `locked` bigint(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_templategroups`
--

CREATE TABLE IF NOT EXISTS `forum_templategroups` (
  `gid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prefix` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_templates`
--

CREATE TABLE IF NOT EXISTS `forum_templates` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL DEFAULT '',
  `template` text NOT NULL,
  `sid` int(10) NOT NULL DEFAULT '0',
  `version` varchar(20) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL DEFAULT '',
  `dateline` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=653 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_templatesets`
--

CREATE TABLE IF NOT EXISTS `forum_templatesets` (
  `sid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_themes`
--

CREATE TABLE IF NOT EXISTS `forum_themes` (
  `tid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `def` smallint(1) NOT NULL DEFAULT '0',
  `properties` text NOT NULL,
  `stylesheets` text NOT NULL,
  `allowedgroups` text NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_themestylesheets`
--

CREATE TABLE IF NOT EXISTS `forum_themestylesheets` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `attachedto` text NOT NULL,
  `stylesheet` text NOT NULL,
  `cachefile` varchar(100) NOT NULL DEFAULT '',
  `lastmodified` bigint(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=110 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_threadprefixes`
--

CREATE TABLE IF NOT EXISTS `forum_threadprefixes` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prefix` varchar(120) NOT NULL DEFAULT '',
  `displaystyle` varchar(200) NOT NULL DEFAULT '',
  `forums` text NOT NULL,
  `groups` text NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_threadratings`
--

CREATE TABLE IF NOT EXISTS `forum_threadratings` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `rating` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ipaddress` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`rid`),
  KEY `tid` (`tid`,`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=248 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_threads`
--

CREATE TABLE IF NOT EXISTS `forum_threads` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(120) NOT NULL DEFAULT '',
  `prefix` smallint(5) unsigned NOT NULL DEFAULT '0',
  `icon` smallint(5) unsigned NOT NULL DEFAULT '0',
  `poll` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(80) NOT NULL DEFAULT '',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `firstpost` int(10) unsigned NOT NULL DEFAULT '0',
  `lastpost` bigint(30) NOT NULL DEFAULT '0',
  `lastposter` varchar(120) NOT NULL DEFAULT '',
  `lastposteruid` int(10) unsigned NOT NULL DEFAULT '0',
  `views` int(100) NOT NULL DEFAULT '0',
  `replies` int(100) NOT NULL DEFAULT '0',
  `closed` varchar(30) NOT NULL DEFAULT '',
  `sticky` int(1) NOT NULL DEFAULT '0',
  `numratings` smallint(5) unsigned NOT NULL DEFAULT '0',
  `totalratings` smallint(5) unsigned NOT NULL DEFAULT '0',
  `notes` text NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '0',
  `unapprovedposts` int(10) unsigned NOT NULL DEFAULT '0',
  `attachmentcount` int(10) unsigned NOT NULL DEFAULT '0',
  `deletetime` int(10) unsigned NOT NULL DEFAULT '0',
  `solved` bigint(30) unsigned NOT NULL DEFAULT '0',
  `oldfid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `oldsubject` varchar(120) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`),
  KEY `fid` (`fid`,`visible`,`sticky`),
  KEY `dateline` (`dateline`),
  KEY `lastpost` (`lastpost`,`fid`),
  KEY `firstpost` (`firstpost`),
  KEY `uid` (`uid`),
  FULLTEXT KEY `subject` (`subject`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13390 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_threadsread`
--

CREATE TABLE IF NOT EXISTS `forum_threadsread` (
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `tid` (`tid`,`uid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_threadsubscriptions`
--

CREATE TABLE IF NOT EXISTS `forum_threadsubscriptions` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `notification` int(1) NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `subscriptionkey` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`sid`),
  KEY `uid` (`uid`),
  KEY `tid` (`tid`,`notification`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=272 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_threadviews`
--

CREATE TABLE IF NOT EXISTS `forum_threadviews` (
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `tid` (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_thx`
--

CREATE TABLE IF NOT EXISTS `forum_thx` (
  `txid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `adduid` int(10) NOT NULL,
  `pid` int(10) NOT NULL,
  `time` bigint(30) NOT NULL,
  PRIMARY KEY (`txid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=154 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_upgrade_data`
--

CREATE TABLE IF NOT EXISTS `forum_upgrade_data` (
  `title` varchar(30) NOT NULL,
  `contents` text NOT NULL,
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forum_userfields`
--

CREATE TABLE IF NOT EXISTS `forum_userfields` (
  `ufid` int(10) unsigned NOT NULL DEFAULT '0',
  `fid1` text NOT NULL,
  `fid3` text NOT NULL,
  `fid4` text,
  `fid7` text,
  PRIMARY KEY (`ufid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forum_usergroups`
--

CREATE TABLE IF NOT EXISTS `forum_usergroups` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `type` smallint(2) NOT NULL DEFAULT '2',
  `title` varchar(120) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `namestyle` varchar(200) NOT NULL DEFAULT '{username}',
  `usertitle` varchar(120) NOT NULL DEFAULT '',
  `stars` smallint(4) NOT NULL DEFAULT '0',
  `starimage` varchar(120) NOT NULL DEFAULT '',
  `image` varchar(120) NOT NULL DEFAULT '',
  `disporder` smallint(6) unsigned NOT NULL,
  `isbannedgroup` int(1) NOT NULL DEFAULT '0',
  `canview` int(1) NOT NULL DEFAULT '0',
  `canviewthreads` int(1) NOT NULL DEFAULT '0',
  `canviewprofiles` int(1) NOT NULL DEFAULT '0',
  `candlattachments` int(1) NOT NULL DEFAULT '0',
  `canpostthreads` int(1) NOT NULL DEFAULT '0',
  `canpostreplys` int(1) NOT NULL DEFAULT '0',
  `canpostattachments` int(1) NOT NULL DEFAULT '0',
  `canratethreads` int(1) NOT NULL DEFAULT '0',
  `caneditposts` int(1) NOT NULL DEFAULT '0',
  `candeleteposts` int(1) NOT NULL DEFAULT '0',
  `candeletethreads` int(1) NOT NULL DEFAULT '0',
  `caneditattachments` int(1) NOT NULL DEFAULT '0',
  `canpostpolls` int(1) NOT NULL DEFAULT '0',
  `canvotepolls` int(1) NOT NULL DEFAULT '0',
  `canundovotes` int(1) NOT NULL DEFAULT '0',
  `canusepms` int(1) NOT NULL DEFAULT '0',
  `cansendpms` int(1) NOT NULL DEFAULT '0',
  `cantrackpms` int(1) NOT NULL DEFAULT '0',
  `candenypmreceipts` int(1) NOT NULL DEFAULT '0',
  `pmquota` int(3) NOT NULL DEFAULT '0',
  `maxpmrecipients` int(4) NOT NULL DEFAULT '5',
  `cansendemail` int(1) NOT NULL DEFAULT '0',
  `maxemails` int(3) NOT NULL DEFAULT '5',
  `canviewmemberlist` int(1) NOT NULL DEFAULT '0',
  `canviewcalendar` int(1) NOT NULL DEFAULT '0',
  `canaddevents` int(1) NOT NULL DEFAULT '0',
  `canbypasseventmod` int(1) NOT NULL DEFAULT '0',
  `canmoderateevents` int(1) NOT NULL DEFAULT '0',
  `canviewonline` int(1) NOT NULL DEFAULT '0',
  `canviewwolinvis` int(1) NOT NULL DEFAULT '0',
  `canviewonlineips` int(1) NOT NULL DEFAULT '0',
  `cancp` int(1) NOT NULL DEFAULT '0',
  `issupermod` int(1) NOT NULL DEFAULT '0',
  `cansearch` int(1) NOT NULL DEFAULT '0',
  `canusercp` int(1) NOT NULL DEFAULT '0',
  `canuploadavatars` int(1) NOT NULL DEFAULT '0',
  `canratemembers` int(1) NOT NULL DEFAULT '0',
  `canchangename` int(1) NOT NULL DEFAULT '0',
  `showforumteam` int(1) NOT NULL DEFAULT '0',
  `usereputationsystem` int(1) NOT NULL DEFAULT '0',
  `cangivereputations` int(1) NOT NULL DEFAULT '0',
  `reputationpower` bigint(30) NOT NULL DEFAULT '0',
  `maxreputationsday` bigint(30) NOT NULL DEFAULT '0',
  `maxreputationsperuser` bigint(30) NOT NULL DEFAULT '0',
  `maxreputationsperthread` bigint(30) NOT NULL DEFAULT '0',
  `candisplaygroup` int(1) NOT NULL DEFAULT '0',
  `attachquota` bigint(30) NOT NULL DEFAULT '0',
  `cancustomtitle` int(1) NOT NULL DEFAULT '0',
  `canwarnusers` int(1) NOT NULL DEFAULT '0',
  `canreceivewarnings` int(1) NOT NULL DEFAULT '0',
  `maxwarningsday` int(3) NOT NULL DEFAULT '3',
  `canmodcp` int(1) NOT NULL DEFAULT '0',
  `showinbirthdaylist` int(1) NOT NULL DEFAULT '0',
  `canoverridepm` int(1) NOT NULL DEFAULT '0',
  `canusesig` int(1) NOT NULL DEFAULT '0',
  `canusesigxposts` bigint(30) NOT NULL DEFAULT '0',
  `signofollow` int(1) NOT NULL DEFAULT '0',
  `cansendemailoverride` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_users`
--

CREATE TABLE IF NOT EXISTS `forum_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(120) NOT NULL DEFAULT '',
  `password` varchar(120) NOT NULL DEFAULT '',
  `salt` varchar(10) NOT NULL DEFAULT '',
  `loginkey` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(220) NOT NULL DEFAULT '',
  `postnum` int(10) NOT NULL DEFAULT '0',
  `avatar` varchar(200) NOT NULL DEFAULT '',
  `avatardimensions` varchar(10) NOT NULL DEFAULT '',
  `avatartype` varchar(10) NOT NULL DEFAULT '0',
  `usergroup` smallint(5) unsigned NOT NULL DEFAULT '0',
  `additionalgroups` varchar(200) NOT NULL DEFAULT '',
  `displaygroup` smallint(5) unsigned NOT NULL DEFAULT '0',
  `usertitle` varchar(250) NOT NULL DEFAULT '',
  `regdate` bigint(30) NOT NULL DEFAULT '0',
  `lastactive` bigint(30) NOT NULL DEFAULT '0',
  `lastvisit` bigint(30) NOT NULL DEFAULT '0',
  `lastpost` bigint(30) NOT NULL DEFAULT '0',
  `website` varchar(200) NOT NULL DEFAULT '',
  `icq` varchar(10) NOT NULL DEFAULT '',
  `aim` varchar(50) NOT NULL DEFAULT '',
  `yahoo` varchar(50) NOT NULL DEFAULT '',
  `msn` varchar(75) NOT NULL DEFAULT '',
  `birthday` varchar(15) NOT NULL DEFAULT '',
  `birthdayprivacy` varchar(4) NOT NULL DEFAULT 'all',
  `signature` text NOT NULL,
  `allownotices` int(1) NOT NULL DEFAULT '0',
  `hideemail` int(1) NOT NULL DEFAULT '0',
  `subscriptionmethod` int(1) NOT NULL DEFAULT '0',
  `invisible` int(1) NOT NULL DEFAULT '0',
  `receivepms` int(1) NOT NULL DEFAULT '0',
  `pmnotice` int(1) NOT NULL DEFAULT '0',
  `pmnotify` int(1) NOT NULL DEFAULT '0',
  `threadmode` varchar(8) NOT NULL DEFAULT '',
  `showsigs` int(1) NOT NULL DEFAULT '0',
  `showavatars` int(1) NOT NULL DEFAULT '0',
  `showquickreply` int(1) NOT NULL DEFAULT '0',
  `showredirect` int(1) NOT NULL DEFAULT '0',
  `ppp` smallint(6) NOT NULL DEFAULT '0',
  `tpp` smallint(6) NOT NULL DEFAULT '0',
  `daysprune` smallint(6) NOT NULL DEFAULT '0',
  `dateformat` varchar(4) NOT NULL DEFAULT '',
  `timeformat` varchar(4) NOT NULL DEFAULT '',
  `timezone` varchar(4) NOT NULL DEFAULT '',
  `dst` int(1) NOT NULL DEFAULT '0',
  `dstcorrection` int(1) NOT NULL DEFAULT '0',
  `buddylist` text NOT NULL,
  `ignorelist` text NOT NULL,
  `style` smallint(5) unsigned NOT NULL DEFAULT '0',
  `away` int(1) NOT NULL DEFAULT '0',
  `awaydate` int(10) unsigned NOT NULL DEFAULT '0',
  `returndate` varchar(15) NOT NULL DEFAULT '',
  `awayreason` varchar(200) NOT NULL DEFAULT '',
  `pmfolders` text NOT NULL,
  `notepad` text NOT NULL,
  `referrer` int(10) unsigned NOT NULL DEFAULT '0',
  `referrals` int(10) unsigned NOT NULL DEFAULT '0',
  `reputation` bigint(30) NOT NULL DEFAULT '0',
  `regip` varchar(50) NOT NULL DEFAULT '',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  `longregip` int(11) NOT NULL DEFAULT '0',
  `longlastip` int(11) NOT NULL DEFAULT '0',
  `language` varchar(50) NOT NULL DEFAULT '',
  `timeonline` bigint(30) NOT NULL DEFAULT '0',
  `showcodebuttons` int(1) NOT NULL DEFAULT '1',
  `totalpms` int(10) NOT NULL DEFAULT '0',
  `unreadpms` int(10) NOT NULL DEFAULT '0',
  `warningpoints` int(3) NOT NULL DEFAULT '0',
  `moderateposts` int(1) NOT NULL DEFAULT '0',
  `moderationtime` bigint(30) NOT NULL DEFAULT '0',
  `suspendposting` int(1) NOT NULL DEFAULT '0',
  `suspensiontime` bigint(30) NOT NULL DEFAULT '0',
  `coppauser` int(1) NOT NULL DEFAULT '0',
  `classicpostbit` int(1) NOT NULL DEFAULT '0',
  `ganalyticsdb` int(11) NOT NULL DEFAULT '0',
  `akismetstopped` int(11) NOT NULL DEFAULT '0',
  `thx` int(11) NOT NULL DEFAULT '0',
  `thxcount` int(11) NOT NULL DEFAULT '0',
  `flobase_characterkey` varchar(32) NOT NULL,
  `receivefrombuddy` int(1) NOT NULL DEFAULT '0',
  `suspendsignature` int(1) NOT NULL DEFAULT '0',
  `suspendsigtime` bigint(30) NOT NULL DEFAULT '0',
  `loginattempts` tinyint(2) NOT NULL DEFAULT '1',
  `usernotes` text NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`),
  KEY `usergroup` (`usergroup`),
  KEY `birthday` (`birthday`),
  KEY `longregip` (`longregip`),
  KEY `longlastip` (`longlastip`),
  KEY `flobase_characterkey` (`flobase_characterkey`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14610 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_usertitles`
--

CREATE TABLE IF NOT EXISTS `forum_usertitles` (
  `utid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `posts` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `stars` smallint(4) NOT NULL DEFAULT '0',
  `starimage` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`utid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_warninglevels`
--

CREATE TABLE IF NOT EXISTS `forum_warninglevels` (
  `lid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `percentage` int(3) NOT NULL DEFAULT '0',
  `action` text NOT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_warnings`
--

CREATE TABLE IF NOT EXISTS `forum_warnings` (
  `wid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(120) NOT NULL DEFAULT '',
  `points` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` bigint(30) NOT NULL DEFAULT '0',
  `issuedby` int(10) unsigned NOT NULL DEFAULT '0',
  `expires` bigint(30) NOT NULL DEFAULT '0',
  `expired` int(1) NOT NULL DEFAULT '0',
  `daterevoked` bigint(30) NOT NULL DEFAULT '0',
  `revokedby` int(10) unsigned NOT NULL DEFAULT '0',
  `revokereason` text NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_warningtypes`
--

CREATE TABLE IF NOT EXISTS `forum_warningtypes` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL DEFAULT '',
  `points` int(10) unsigned NOT NULL DEFAULT '0',
  `expirationtime` bigint(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `server_100floor`
--

CREATE TABLE IF NOT EXISTS `server_100floor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_100floor_코드` varchar(9) NOT NULL,
  `server_100floor_이름` varchar(5) NOT NULL,
  `server_100floor_시간` varchar(3) NOT NULL,
  `server_100floor_종류코드` varchar(1) NOT NULL,
  `server_100floor_몬스터종류갯수` varchar(1) NOT NULL,
  `server_100floor_몬스터KEY_1` varchar(9) NOT NULL,
  `server_100floor_몬스터갯수_1` varchar(2) NOT NULL,
  `server_100floor_몬스터KEY_2` varchar(9) NOT NULL,
  `server_100floor_몬스터갯수_2` varchar(1) NOT NULL,
  `server_100floor_몬스터KEY_3` varchar(9) NOT NULL,
  `server_100floor_몬스터갯수_3` varchar(1) NOT NULL,
  `server_100floor_몬스터KEY_4` varchar(1) NOT NULL,
  `server_100floor_몬스터갯수_4` varchar(1) NOT NULL,
  `server_100floor_몬스터KEY_5` varchar(1) NOT NULL,
  `server_100floor_몬스터갯수_5` varchar(1) NOT NULL,
  `server_100floor_몬스터KEY_6` varchar(1) NOT NULL,
  `server_100floor_몬스터갯수_6` varchar(1) NOT NULL,
  `server_100floor_몬스터KEY_7` varchar(1) NOT NULL,
  `server_100floor_몬스터갯수_7` varchar(1) NOT NULL,
  `server_100floor_몬스터KEY_8` varchar(1) NOT NULL,
  `server_100floor_몬스터갯수_8` varchar(1) NOT NULL,
  `server_100floor_몬스터KEY_9` varchar(1) NOT NULL,
  `server_100floor_몬스터갯수_9` varchar(1) NOT NULL,
  `server_100floor_몬스터KEY_10` varchar(1) NOT NULL,
  `server_100floor_몬스터갯수_10` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=101 ;

-- --------------------------------------------------------

--
-- Table structure for table `server_class`
--

CREATE TABLE IF NOT EXISTS `server_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_코드` varchar(255) DEFAULT NULL,
  `class_이름` varchar(255) DEFAULT NULL,
  `class_전직단계` varchar(255) DEFAULT NULL,
  `class_원형클래스` varchar(255) DEFAULT NULL,
  `class_필요클래스` varchar(255) DEFAULT NULL,
  `class_필요육상레벨` varchar(255) DEFAULT NULL,
  `class_필요해상레벨` varchar(255) DEFAULT NULL,
  `class_STR` varchar(255) DEFAULT NULL,
  `class_DEX` varchar(255) DEFAULT NULL,
  `class_CON` varchar(255) DEFAULT NULL,
  `class_INT` varchar(255) DEFAULT NULL,
  `class_WIS` varchar(255) DEFAULT NULL,
  `class_VOL` varchar(255) DEFAULT NULL,
  `class_LUC` varchar(255) DEFAULT NULL,
  `class_BAL` varchar(255) DEFAULT NULL,
  `class_전직퀘스트` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `server_description`
--

CREATE TABLE IF NOT EXISTS `server_description` (
  `Code` varchar(9) NOT NULL,
  `Name` varchar(18) NOT NULL,
  `Korea` varchar(84) NOT NULL,
  `Japan` varchar(65) NOT NULL,
  `English` varchar(208) NOT NULL,
  `German` varchar(234) NOT NULL,
  `Italian` varchar(197) NOT NULL,
  `Spanish` varchar(210) NOT NULL,
  `Portuguese` varchar(169) NOT NULL,
  `French` varchar(204) NOT NULL,
  `Turkish` varchar(237) NOT NULL,
  `China` varchar(69) NOT NULL,
  `Taiwan` varchar(114) NOT NULL,
  `Indonesia` varchar(187) NOT NULL,
  PRIMARY KEY (`Code`),
  FULLTEXT KEY `Korea` (`Korea`),
  FULLTEXT KEY `Japan` (`Japan`),
  FULLTEXT KEY `English` (`English`),
  FULLTEXT KEY `German` (`German`),
  FULLTEXT KEY `Italian` (`Italian`),
  FULLTEXT KEY `Spanish` (`Spanish`),
  FULLTEXT KEY `Portuguese` (`Portuguese`),
  FULLTEXT KEY `French` (`French`),
  FULLTEXT KEY `Turkish` (`Turkish`),
  FULLTEXT KEY `China` (`China`),
  FULLTEXT KEY `Taiwan` (`Taiwan`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_exptable_land`
--

CREATE TABLE IF NOT EXISTS `server_exptable_land` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_exptable_land_코드` varchar(4) NOT NULL,
  `server_exptable_land_다음레벨필요누적경험치` varchar(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=101 ;

-- --------------------------------------------------------

--
-- Table structure for table `server_exptable_sea`
--

CREATE TABLE IF NOT EXISTS `server_exptable_sea` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_exptable_sea_코드` varchar(4) NOT NULL,
  `server_exptable_sea_다음레벨필요누적경험치` varchar(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=101 ;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_accessoryitem`
--

CREATE TABLE IF NOT EXISTS `server_item_accessoryitem` (
  `name_Korea` varchar(23) NOT NULL,
  `name_Japan` varchar(28) NOT NULL,
  `name_English` varchar(46) NOT NULL,
  `name_German` varchar(46) NOT NULL,
  `name_Italian` varchar(46) NOT NULL,
  `name_Spanish` varchar(46) NOT NULL,
  `name_Portuguese` varchar(46) NOT NULL,
  `name_French` varchar(46) NOT NULL,
  `name_Turkish` varchar(46) NOT NULL,
  `name_China` varchar(41) NOT NULL,
  `name_Taiwan` varchar(41) NOT NULL,
  `name_Indonesia` varchar(46) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(24) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(5) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_구분코드` varchar(1) NOT NULL,
  `item_최대업글단계` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_GM용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_마항력` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(10) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(10) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(9) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_baititem`
--

CREATE TABLE IF NOT EXISTS `server_item_baititem` (
  `name_Korea` varchar(6) NOT NULL,
  `name_Japan` varchar(6) NOT NULL,
  `name_English` varchar(17) NOT NULL,
  `name_German` varchar(17) NOT NULL,
  `name_Italian` varchar(17) NOT NULL,
  `name_Spanish` varchar(17) NOT NULL,
  `name_Portuguese` varchar(17) NOT NULL,
  `name_French` varchar(17) NOT NULL,
  `name_Turkish` varchar(17) NOT NULL,
  `name_China` varchar(5) NOT NULL,
  `name_Taiwan` varchar(6) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(6) NOT NULL,
  `item_사용가능무기` varchar(1) NOT NULL,
  `item_제한레벨` varchar(2) NOT NULL,
  `item_최대탄수` varchar(3) NOT NULL,
  `item_최대중복개수` varchar(3) NOT NULL,
  `item_물공력` varchar(1) NOT NULL,
  `item_속성타입` varchar(1) NOT NULL,
  `item_속공력` varchar(1) NOT NULL,
  `item_추가사거리` varchar(1) NOT NULL,
  `item_추가밸런스` varchar(1) NOT NULL,
  `item_폭발반경` varchar(1) NOT NULL,
  `item_지속시간밀초` varchar(1) NOT NULL,
  `item_지속효과코드` varchar(3) NOT NULL,
  `item_수치연산자` varchar(1) NOT NULL,
  `item_지속효과값` varchar(10) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_bulletitem`
--

CREATE TABLE IF NOT EXISTS `server_item_bulletitem` (
  `name_Korea` varchar(7) NOT NULL,
  `name_Japan` varchar(6) NOT NULL,
  `name_English` varchar(23) NOT NULL,
  `name_German` varchar(23) NOT NULL,
  `name_Italian` varchar(23) NOT NULL,
  `name_Spanish` varchar(23) NOT NULL,
  `name_Portuguese` varchar(23) NOT NULL,
  `name_French` varchar(23) NOT NULL,
  `name_Turkish` varchar(23) NOT NULL,
  `name_China` varchar(7) NOT NULL,
  `name_Taiwan` varchar(7) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(7) NOT NULL,
  `item_사용가능무기` varchar(1) NOT NULL,
  `item_제한레벨` varchar(1) NOT NULL,
  `item_최대탄수` varchar(3) NOT NULL,
  `item_최대중복개수` varchar(4) NOT NULL,
  `item_물공력` varchar(1) NOT NULL,
  `item_속성타입` varchar(1) NOT NULL,
  `item_속공력` varchar(1) NOT NULL,
  `item_추가사거리` varchar(1) NOT NULL,
  `item_추가밸런스` varchar(1) NOT NULL,
  `item_폭발반경` varchar(1) NOT NULL,
  `item_지속시간밀초` varchar(1) NOT NULL,
  `item_지속효과코드` varchar(10) NOT NULL,
  `item_수치연산자` varchar(1) NOT NULL,
  `item_지속효과값` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_cloakitem`
--

CREATE TABLE IF NOT EXISTS `server_item_cloakitem` (
  `name_Korea` varchar(24) NOT NULL,
  `name_Japan` varchar(25) NOT NULL,
  `name_English` varchar(33) NOT NULL,
  `name_German` varchar(33) NOT NULL,
  `name_Italian` varchar(33) NOT NULL,
  `name_Spanish` varchar(33) NOT NULL,
  `name_Portuguese` varchar(33) NOT NULL,
  `name_French` varchar(33) NOT NULL,
  `name_Turkish` varchar(33) NOT NULL,
  `name_China` varchar(33) NOT NULL,
  `name_Taiwan` varchar(33) NOT NULL,
  `name_Indonesia` varchar(40) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(28) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(4) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_업그레이드코드` varchar(1) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(1) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(1) NOT NULL,
  `item_최대내구도` varchar(6) NOT NULL,
  `item_최소물공력` varchar(1) NOT NULL,
  `item_최대물공력` varchar(1) NOT NULL,
  `item_최소마공력` varchar(1) NOT NULL,
  `item_최대마공력` varchar(1) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_물공쿨타임밀초` varchar(1) NOT NULL,
  `item_물공최소거리` varchar(1) NOT NULL,
  `item_물공최대거리` varchar(1) NOT NULL,
  `item_마공케스팅타임밀초` varchar(1) NOT NULL,
  `item_마항력` varchar(1) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_마공명` varchar(1) NOT NULL,
  `item_물공피` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_물공모션타임밀초1` varchar(1) NOT NULL,
  `item_물공모션타임밀초2` varchar(1) NOT NULL,
  `item_크리공격모션타임밀초` varchar(1) NOT NULL,
  `item_최대업글단계` varchar(1) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(1) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(10) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_consumeitem`
--

CREATE TABLE IF NOT EXISTS `server_item_consumeitem` (
  `name_Korea` varchar(24) NOT NULL,
  `name_Japan` varchar(31) NOT NULL,
  `name_English` varchar(70) NOT NULL,
  `name_German` varchar(70) NOT NULL,
  `name_Italian` varchar(73) NOT NULL,
  `name_Spanish` varchar(70) NOT NULL,
  `name_Portuguese` varchar(70) NOT NULL,
  `name_French` varchar(70) NOT NULL,
  `name_Turkish` varchar(70) NOT NULL,
  `name_China` varchar(36) NOT NULL,
  `name_Taiwan` varchar(62) NOT NULL,
  `name_Indonesia` varchar(70) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(21) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(5) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_육상최소레벨` varchar(2) NOT NULL,
  `item_해상최소레벨` varchar(2) NOT NULL,
  `item_쿨타임계열` varchar(2) NOT NULL,
  `item_쿨타임밀초` varchar(6) NOT NULL,
  `item_캐스팅시간밀초` varchar(1) NOT NULL,
  `item_타입` varchar(10) NOT NULL,
  `item_성능` varchar(10) NOT NULL,
  `item_스킬코드` varchar(8) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(3) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_crewpotionitem`
--

CREATE TABLE IF NOT EXISTS `server_item_crewpotionitem` (
  `name_Korea` varchar(8) NOT NULL,
  `name_Japan` varchar(8) NOT NULL,
  `name_English` varchar(8) NOT NULL,
  `name_German` varchar(8) NOT NULL,
  `name_Italian` varchar(8) NOT NULL,
  `name_Spanish` varchar(8) NOT NULL,
  `name_Portuguese` varchar(8) NOT NULL,
  `name_French` varchar(8) NOT NULL,
  `name_Turkish` varchar(8) NOT NULL,
  `name_China` varchar(8) NOT NULL,
  `name_Taiwan` varchar(8) NOT NULL,
  `name_Indonesia` varchar(8) NOT NULL,
  `item_코드` varchar(8) NOT NULL,
  `item_이름` varchar(3) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(5) NOT NULL,
  `item_쿨타임밀초` varchar(5) NOT NULL,
  `item_타입` varchar(1) NOT NULL,
  `item_성능` varchar(3) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(3) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_effect`
--

CREATE TABLE IF NOT EXISTS `server_item_effect` (
  `코드` varchar(7) NOT NULL,
  `효과코드` smallint(6) NOT NULL DEFAULT '0',
  `이름` varchar(18) NOT NULL,
  `Operator` varchar(1) NOT NULL,
  `Interval0101` varchar(10) NOT NULL,
  `Interval0102` varchar(10) NOT NULL,
  `Interval0103` varchar(10) NOT NULL,
  `Interval0104` varchar(10) NOT NULL,
  `Interval0105` varchar(10) NOT NULL,
  `Interval0201` varchar(10) NOT NULL,
  `Interval0202` varchar(10) NOT NULL,
  `Interval0203` varchar(10) NOT NULL,
  `Interval0204` varchar(10) NOT NULL,
  `Interval0205` varchar(10) NOT NULL,
  `Interval0301` varchar(10) NOT NULL,
  `Interval0302` varchar(10) NOT NULL,
  `Interval0303` varchar(10) NOT NULL,
  `Interval0304` varchar(10) NOT NULL,
  `Interval0305` varchar(10) NOT NULL,
  `Interval0401` varchar(10) NOT NULL,
  `Interval0402` varchar(10) NOT NULL,
  `Interval0403` varchar(10) NOT NULL,
  `Interval0404` varchar(10) NOT NULL,
  `Interval0405` varchar(10) NOT NULL,
  `Interval0501` varchar(10) NOT NULL,
  `Interval0502` varchar(10) NOT NULL,
  `Interval0503` varchar(10) NOT NULL,
  `Interval0504` varchar(10) NOT NULL,
  `Interval0505` varchar(10) NOT NULL,
  `Interval0601` varchar(10) NOT NULL,
  `Interval0602` varchar(10) NOT NULL,
  `Interval0603` varchar(10) NOT NULL,
  `Interval0604` varchar(10) NOT NULL,
  `Interval0605` varchar(10) NOT NULL,
  `Interval0701` varchar(10) NOT NULL,
  `Interval0702` varchar(10) NOT NULL,
  `Interval0703` varchar(10) NOT NULL,
  `Interval0704` varchar(10) NOT NULL,
  `Interval0705` varchar(10) NOT NULL,
  `Interval0801` varchar(10) NOT NULL,
  `Interval0802` varchar(10) NOT NULL,
  `Interval0803` varchar(10) NOT NULL,
  `Interval0804` varchar(10) NOT NULL,
  `Interval0805` varchar(10) NOT NULL,
  `Interval0901` varchar(10) NOT NULL,
  `Interval0902` varchar(10) NOT NULL,
  `Interval0903` varchar(10) NOT NULL,
  `Interval0904` varchar(10) NOT NULL,
  `Interval0905` varchar(10) NOT NULL,
  `Interval1001` varchar(10) NOT NULL,
  `Interval1002` varchar(10) NOT NULL,
  `Interval1003` varchar(10) NOT NULL,
  `Interval1004` varchar(10) NOT NULL,
  `Interval1005` varchar(10) NOT NULL,
  PRIMARY KEY (`효과코드`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_fishingitem`
--

CREATE TABLE IF NOT EXISTS `server_item_fishingitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(9) NOT NULL,
  `name_English` varchar(26) NOT NULL,
  `name_German` varchar(26) NOT NULL,
  `name_Italian` varchar(26) NOT NULL,
  `name_Spanish` varchar(26) NOT NULL,
  `name_Portuguese` varchar(26) NOT NULL,
  `name_French` varchar(26) NOT NULL,
  `name_Turkish` varchar(26) NOT NULL,
  `name_China` varchar(9) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(9) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(7) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(4) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_업그레이드코드` varchar(1) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(1) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(1) NOT NULL,
  `item_최대내구도` varchar(6) NOT NULL,
  `item_최소물공력` varchar(1) NOT NULL,
  `item_최대물공력` varchar(1) NOT NULL,
  `item_최소마공력` varchar(1) NOT NULL,
  `item_최대마공력` varchar(1) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_물공쿨타임밀초` varchar(1) NOT NULL,
  `item_물공최소거리` varchar(1) NOT NULL,
  `item_물공최대거리` varchar(1) NOT NULL,
  `item_마공케스팅타임밀초` varchar(1) NOT NULL,
  `item_마항력` varchar(1) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_마공명` varchar(1) NOT NULL,
  `item_물공피` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_물공모션타임밀초1` varchar(4) NOT NULL,
  `item_물공모션타임밀초2` varchar(1) NOT NULL,
  `item_크리공격모션타임밀초` varchar(1) NOT NULL,
  `item_최대업글단계` varchar(1) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_fishmaterialitem`
--

CREATE TABLE IF NOT EXISTS `server_item_fishmaterialitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(11) NOT NULL,
  `name_English` varchar(20) NOT NULL,
  `name_German` varchar(20) NOT NULL,
  `name_Italian` varchar(20) NOT NULL,
  `name_Spanish` varchar(20) NOT NULL,
  `name_Portuguese` varchar(20) NOT NULL,
  `name_French` varchar(20) NOT NULL,
  `name_Turkish` varchar(20) NOT NULL,
  `name_China` varchar(5) NOT NULL,
  `name_Taiwan` varchar(5) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(9) NOT NULL,
  `item_사용구분` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(2) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_freemarketitem`
--

CREATE TABLE IF NOT EXISTS `server_item_freemarketitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(9) NOT NULL,
  `name_English` varchar(9) NOT NULL,
  `name_German` varchar(9) NOT NULL,
  `name_Italian` varchar(9) NOT NULL,
  `name_Spanish` varchar(9) NOT NULL,
  `name_Portuguese` varchar(9) NOT NULL,
  `name_French` varchar(9) NOT NULL,
  `name_Turkish` varchar(9) NOT NULL,
  `name_China` varchar(9) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(9) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(4) NOT NULL,
  `item_대상코드` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_fusionhelpbreakitem`
--

CREATE TABLE IF NOT EXISTS `server_item_fusionhelpbreakitem` (
  `name_Korea` varchar(10) NOT NULL,
  `name_Japan` varchar(8) NOT NULL,
  `name_English` varchar(22) NOT NULL,
  `name_German` varchar(25) NOT NULL,
  `name_Italian` varchar(23) NOT NULL,
  `name_Spanish` varchar(22) NOT NULL,
  `name_Portuguese` varchar(28) NOT NULL,
  `name_French` varchar(22) NOT NULL,
  `name_Turkish` varchar(22) NOT NULL,
  `name_China` varchar(19) NOT NULL,
  `name_Taiwan` varchar(19) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(10) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_아이템등급` varchar(1) NOT NULL,
  `item_사용구분` varchar(1) NOT NULL,
  `item_일시코드1` varchar(1) NOT NULL,
  `item_연산자1` varchar(1) NOT NULL,
  `item_일시값1` varchar(5) NOT NULL,
  `item_일시코드2` varchar(10) NOT NULL,
  `item_연산자2` varchar(1) NOT NULL,
  `item_일시값2` varchar(1) NOT NULL,
  `item_초기화방지` varchar(1) NOT NULL,
  `item_판매가격` varchar(1) NOT NULL,
  `item_처분가격` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(2) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_gauntletitem`
--

CREATE TABLE IF NOT EXISTS `server_item_gauntletitem` (
  `name_Korea` varchar(17) NOT NULL,
  `name_Japan` varchar(17) NOT NULL,
  `name_English` varchar(35) NOT NULL,
  `name_German` varchar(35) NOT NULL,
  `name_Italian` varchar(35) NOT NULL,
  `name_Spanish` varchar(35) NOT NULL,
  `name_Portuguese` varchar(35) NOT NULL,
  `name_French` varchar(35) NOT NULL,
  `name_Turkish` varchar(35) NOT NULL,
  `name_China` varchar(35) NOT NULL,
  `name_Taiwan` varchar(35) NOT NULL,
  `name_Indonesia` varchar(35) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(18) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_업그레이드코드` varchar(9) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(1) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(1) NOT NULL,
  `item_최대내구도` varchar(6) NOT NULL,
  `item_최소물공력` varchar(1) NOT NULL,
  `item_최대물공력` varchar(1) NOT NULL,
  `item_최소마공력` varchar(1) NOT NULL,
  `item_최대마공력` varchar(1) NOT NULL,
  `item_물방력` varchar(3) NOT NULL,
  `item_물공쿨타임밀초` varchar(1) NOT NULL,
  `item_물공최소거리` varchar(1) NOT NULL,
  `item_물공최대거리` varchar(1) NOT NULL,
  `item_마공케스팅타임밀초` varchar(1) NOT NULL,
  `item_마항력` varchar(3) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_마공명` varchar(1) NOT NULL,
  `item_물공피` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_물공모션타임밀초1` varchar(1) NOT NULL,
  `item_물공모션타임밀초2` varchar(1) NOT NULL,
  `item_크리공격모션타임밀초` varchar(1) NOT NULL,
  `item_최대업글단계` varchar(2) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(9) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_gunitem`
--

CREATE TABLE IF NOT EXISTS `server_item_gunitem` (
  `name_Korea` varchar(14) NOT NULL,
  `name_Japan` varchar(15) NOT NULL,
  `name_English` varchar(29) NOT NULL,
  `name_German` varchar(29) NOT NULL,
  `name_Italian` varchar(29) NOT NULL,
  `name_Spanish` varchar(29) NOT NULL,
  `name_Portuguese` varchar(29) NOT NULL,
  `name_French` varchar(29) NOT NULL,
  `name_Turkish` varchar(29) NOT NULL,
  `name_China` varchar(25) NOT NULL,
  `name_Taiwan` varchar(29) NOT NULL,
  `name_Indonesia` varchar(29) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(14) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(2) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_업그레이드코드` varchar(9) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(1) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(1) NOT NULL,
  `item_최대내구도` varchar(6) NOT NULL,
  `item_최소물공력` varchar(3) NOT NULL,
  `item_최대물공력` varchar(3) NOT NULL,
  `item_최소마공력` varchar(3) NOT NULL,
  `item_최대마공력` varchar(3) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_물공쿨타임밀초` varchar(4) NOT NULL,
  `item_물공최소거리` varchar(1) NOT NULL,
  `item_물공최대거리` varchar(4) NOT NULL,
  `item_마공케스팅타임밀초` varchar(1) NOT NULL,
  `item_마항력` varchar(1) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_마공명` varchar(1) NOT NULL,
  `item_물공피` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_물공모션타임밀초1` varchar(3) NOT NULL,
  `item_물공모션타임밀초2` varchar(3) NOT NULL,
  `item_크리공격모션타임밀초` varchar(3) NOT NULL,
  `item_최대업글단계` varchar(2) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(10) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(9) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_hatitem`
--

CREATE TABLE IF NOT EXISTS `server_item_hatitem` (
  `name_Korea` varchar(20) NOT NULL,
  `name_Japan` varchar(22) NOT NULL,
  `name_English` varchar(27) NOT NULL,
  `name_German` varchar(27) NOT NULL,
  `name_Italian` varchar(27) NOT NULL,
  `name_Spanish` varchar(27) NOT NULL,
  `name_Portuguese` varchar(27) NOT NULL,
  `name_French` varchar(27) NOT NULL,
  `name_Turkish` varchar(27) NOT NULL,
  `name_China` varchar(24) NOT NULL,
  `name_Taiwan` varchar(25) NOT NULL,
  `name_Indonesia` varchar(27) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(24) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(4) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_업그레이드코드` varchar(1) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(1) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(1) NOT NULL,
  `item_최대내구도` varchar(6) NOT NULL,
  `item_최소물공력` varchar(1) NOT NULL,
  `item_최대물공력` varchar(1) NOT NULL,
  `item_최소마공력` varchar(1) NOT NULL,
  `item_최대마공력` varchar(1) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_물공쿨타임밀초` varchar(1) NOT NULL,
  `item_물공최소거리` varchar(1) NOT NULL,
  `item_물공최대거리` varchar(1) NOT NULL,
  `item_마공케스팅타임밀초` varchar(1) NOT NULL,
  `item_마항력` varchar(1) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_마공명` varchar(1) NOT NULL,
  `item_물공피` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_물공모션타임밀초1` varchar(1) NOT NULL,
  `item_물공모션타임밀초2` varchar(1) NOT NULL,
  `item_크리공격모션타임밀초` varchar(1) NOT NULL,
  `item_최대업글단계` varchar(1) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(10) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_idtable`
--

CREATE TABLE IF NOT EXISTS `server_item_idtable` (
  `itemid` varchar(9) NOT NULL,
  `tableid` varchar(19) NOT NULL,
  `itempicture` varchar(6) NOT NULL,
  `characterpicture` varchar(9) NOT NULL,
  `usedbyrecipe` text NOT NULL,
  `producedbyrecipe` text NOT NULL,
  `questreward` text NOT NULL,
  `name_Korea` varchar(28) NOT NULL,
  `name_Japan` varchar(37) NOT NULL,
  `name_English` varchar(70) NOT NULL,
  `name_German` varchar(70) NOT NULL,
  `name_Italian` varchar(73) NOT NULL,
  `name_Spanish` varchar(70) NOT NULL,
  `name_Portuguese` varchar(70) NOT NULL,
  `name_French` varchar(70) NOT NULL,
  `name_Turkish` varchar(70) NOT NULL,
  `name_China` varchar(43) NOT NULL,
  `name_Taiwan` varchar(62) NOT NULL,
  `name_Indonesia` varchar(70) NOT NULL,
  PRIMARY KEY (`itemid`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_knifeitem`
--

CREATE TABLE IF NOT EXISTS `server_item_knifeitem` (
  `name_Korea` varchar(22) NOT NULL,
  `name_Japan` varchar(26) NOT NULL,
  `name_English` varchar(42) NOT NULL,
  `name_German` varchar(42) NOT NULL,
  `name_Italian` varchar(42) NOT NULL,
  `name_Spanish` varchar(42) NOT NULL,
  `name_Portuguese` varchar(42) NOT NULL,
  `name_French` varchar(42) NOT NULL,
  `name_Turkish` varchar(42) NOT NULL,
  `name_China` varchar(42) NOT NULL,
  `name_Taiwan` varchar(42) NOT NULL,
  `name_Indonesia` varchar(42) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(27) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(4) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_업그레이드코드` varchar(9) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(1) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(10) NOT NULL,
  `item_최대내구도` varchar(6) NOT NULL,
  `item_최소물공력` varchar(4) NOT NULL,
  `item_최대물공력` varchar(4) NOT NULL,
  `item_최소마공력` varchar(3) NOT NULL,
  `item_최대마공력` varchar(3) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_물공쿨타임밀초` varchar(4) NOT NULL,
  `item_물공최소거리` varchar(1) NOT NULL,
  `item_물공최대거리` varchar(2) NOT NULL,
  `item_마공케스팅타임밀초` varchar(1) NOT NULL,
  `item_마항력` varchar(1) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_마공명` varchar(1) NOT NULL,
  `item_물공피` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_물공모션타임밀초1` varchar(4) NOT NULL,
  `item_물공모션타임밀초2` varchar(4) NOT NULL,
  `item_크리공격모션타임밀초` varchar(4) NOT NULL,
  `item_최대업글단계` varchar(2) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(10) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(9) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_loweritem`
--

CREATE TABLE IF NOT EXISTS `server_item_loweritem` (
  `name_Korea` varchar(16) NOT NULL,
  `name_Japan` varchar(21) NOT NULL,
  `name_English` varchar(43) NOT NULL,
  `name_German` varchar(43) NOT NULL,
  `name_Italian` varchar(43) NOT NULL,
  `name_Spanish` varchar(43) NOT NULL,
  `name_Portuguese` varchar(43) NOT NULL,
  `name_French` varchar(43) NOT NULL,
  `name_Turkish` varchar(43) NOT NULL,
  `name_China` varchar(43) NOT NULL,
  `name_Taiwan` varchar(43) NOT NULL,
  `name_Indonesia` varchar(43) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(16) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_업그레이드코드` varchar(9) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(1) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(1) NOT NULL,
  `item_최대내구도` varchar(6) NOT NULL,
  `item_최소물공력` varchar(1) NOT NULL,
  `item_최대물공력` varchar(1) NOT NULL,
  `item_최소마공력` varchar(1) NOT NULL,
  `item_최대마공력` varchar(1) NOT NULL,
  `item_물방력` varchar(3) NOT NULL,
  `item_물공쿨타임밀초` varchar(1) NOT NULL,
  `item_물공최소거리` varchar(1) NOT NULL,
  `item_물공최대거리` varchar(1) NOT NULL,
  `item_마공케스팅타임밀초` varchar(1) NOT NULL,
  `item_마항력` varchar(3) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_마공명` varchar(1) NOT NULL,
  `item_물공피` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_물공모션타임밀초1` varchar(1) NOT NULL,
  `item_물공모션타임밀초2` varchar(1) NOT NULL,
  `item_크리공격모션타임밀초` varchar(1) NOT NULL,
  `item_최대업글단계` varchar(2) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(9) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_magicballitem`
--

CREATE TABLE IF NOT EXISTS `server_item_magicballitem` (
  `name_Korea` varchar(15) NOT NULL,
  `name_Japan` varchar(13) NOT NULL,
  `name_English` varchar(21) NOT NULL,
  `name_German` varchar(21) NOT NULL,
  `name_Italian` varchar(21) NOT NULL,
  `name_Spanish` varchar(21) NOT NULL,
  `name_Portuguese` varchar(21) NOT NULL,
  `name_French` varchar(21) NOT NULL,
  `name_Turkish` varchar(21) NOT NULL,
  `name_China` varchar(18) NOT NULL,
  `name_Taiwan` varchar(21) NOT NULL,
  `name_Indonesia` varchar(21) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(15) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(2) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_업그레이드코드` varchar(9) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(1) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(10) NOT NULL,
  `item_최대내구도` varchar(6) NOT NULL,
  `item_최소물공력` varchar(3) NOT NULL,
  `item_최대물공력` varchar(3) NOT NULL,
  `item_최소마공력` varchar(3) NOT NULL,
  `item_최대마공력` varchar(3) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_물공쿨타임밀초` varchar(4) NOT NULL,
  `item_물공최소거리` varchar(1) NOT NULL,
  `item_물공최대거리` varchar(4) NOT NULL,
  `item_마공케스팅타임밀초` varchar(1) NOT NULL,
  `item_마항력` varchar(1) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_마공명` varchar(1) NOT NULL,
  `item_물공피` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_물공모션타임밀초1` varchar(3) NOT NULL,
  `item_물공모션타임밀초2` varchar(3) NOT NULL,
  `item_크리공격모션타임밀초` varchar(3) NOT NULL,
  `item_최대업글단계` varchar(2) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(10) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(9) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_materialitem`
--

CREATE TABLE IF NOT EXISTS `server_item_materialitem` (
  `name_Korea` varchar(1) NOT NULL,
  `name_Japan` varchar(1) NOT NULL,
  `name_English` varchar(1) NOT NULL,
  `name_German` varchar(1) NOT NULL,
  `name_Italian` varchar(1) NOT NULL,
  `name_Spanish` varchar(1) NOT NULL,
  `name_Portuguese` varchar(1) NOT NULL,
  `name_French` varchar(1) NOT NULL,
  `name_Turkish` varchar(1) NOT NULL,
  `name_China` varchar(1) NOT NULL,
  `name_Taiwan` varchar(1) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(1) NOT NULL,
  `item_이름` varchar(1) NOT NULL,
  `item_사용구분` varchar(1) NOT NULL,
  `item_판매가격` varchar(1) NOT NULL,
  `item_처분가격` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_ornamentitem`
--

CREATE TABLE IF NOT EXISTS `server_item_ornamentitem` (
  `name_Korea` varchar(3) NOT NULL,
  `name_Japan` varchar(4) NOT NULL,
  `name_English` varchar(6) NOT NULL,
  `name_German` varchar(6) NOT NULL,
  `name_Italian` varchar(6) NOT NULL,
  `name_Spanish` varchar(6) NOT NULL,
  `name_Portuguese` varchar(6) NOT NULL,
  `name_French` varchar(6) NOT NULL,
  `name_Turkish` varchar(6) NOT NULL,
  `name_China` varchar(2) NOT NULL,
  `name_Taiwan` varchar(2) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(3) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(5) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_구분코드` varchar(1) NOT NULL,
  `item_최대업글단계` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_GM용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_마항력` varchar(3) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(1) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(1) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_petcombinehelpitem`
--

CREATE TABLE IF NOT EXISTS `server_item_petcombinehelpitem` (
  `name_Korea` varchar(17) NOT NULL,
  `name_Japan` varchar(17) NOT NULL,
  `name_English` varchar(27) NOT NULL,
  `name_German` varchar(27) NOT NULL,
  `name_Italian` varchar(27) NOT NULL,
  `name_Spanish` varchar(28) NOT NULL,
  `name_Portuguese` varchar(38) NOT NULL,
  `name_French` varchar(27) NOT NULL,
  `name_Turkish` varchar(34) NOT NULL,
  `name_China` varchar(27) NOT NULL,
  `name_Taiwan` varchar(27) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(17) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_효과코드` varchar(1) NOT NULL,
  `item_증가최소값` varchar(1) NOT NULL,
  `item_증가최대값` varchar(1) NOT NULL,
  `item_성공확률보정` varchar(2) NOT NULL,
  `item_소실방지` varchar(1) NOT NULL,
  `item_감소방지` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(2) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_petcombineitem`
--

CREATE TABLE IF NOT EXISTS `server_item_petcombineitem` (
  `name_Korea` varchar(8) NOT NULL,
  `name_Japan` varchar(8) NOT NULL,
  `name_English` varchar(27) NOT NULL,
  `name_German` varchar(27) NOT NULL,
  `name_Italian` varchar(27) NOT NULL,
  `name_Spanish` varchar(27) NOT NULL,
  `name_Portuguese` varchar(28) NOT NULL,
  `name_French` varchar(27) NOT NULL,
  `name_Turkish` varchar(27) NOT NULL,
  `name_China` varchar(27) NOT NULL,
  `name_Taiwan` varchar(27) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(8) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_효과코드` varchar(1) NOT NULL,
  `item_증가최소값` varchar(3) NOT NULL,
  `item_증가최대값` varchar(4) NOT NULL,
  `item_성공확률보정` varchar(1) NOT NULL,
  `item_소실방지` varchar(1) NOT NULL,
  `item_감소방지` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(2) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_petitem`
--

CREATE TABLE IF NOT EXISTS `server_item_petitem` (
  `name_Korea` varchar(23) NOT NULL,
  `name_Japan` varchar(24) NOT NULL,
  `name_English` varchar(33) NOT NULL,
  `name_German` varchar(33) NOT NULL,
  `name_Italian` varchar(33) NOT NULL,
  `name_Spanish` varchar(33) NOT NULL,
  `name_Portuguese` varchar(33) NOT NULL,
  `name_French` varchar(33) NOT NULL,
  `name_Turkish` varchar(33) NOT NULL,
  `name_China` varchar(19) NOT NULL,
  `name_Taiwan` varchar(33) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(20) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(5) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_육상최소레벨` varchar(1) NOT NULL,
  `item_해상최소레벨` varchar(1) NOT NULL,
  `item_쿨타임계열` varchar(1) NOT NULL,
  `item_쿨타임밀초` varchar(5) NOT NULL,
  `item_캐스팅시간밀초` varchar(1) NOT NULL,
  `item_타입` varchar(1) NOT NULL,
  `item_공격형타입` varchar(10) NOT NULL,
  `item_성능` varchar(3) NOT NULL,
  `item_펫리소스데이터C` varchar(9) NOT NULL,
  `item_펫리소스데이터B` varchar(9) NOT NULL,
  `item_펫리소스데이터A` varchar(9) NOT NULL,
  `item_펫리소스데이터S` varchar(9) NOT NULL,
  `item_펫리소스데이터SS` varchar(9) NOT NULL,
  `item_용기` varchar(10) NOT NULL,
  `item_인내` varchar(10) NOT NULL,
  `item_지혜` varchar(10) NOT NULL,
  `item_str` varchar(1) NOT NULL,
  `item_dex` varchar(2) NOT NULL,
  `item_con` varchar(2) NOT NULL,
  `item_int` varchar(2) NOT NULL,
  `item_wis` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_펫봉인타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_petskillstoneitem`
--

CREATE TABLE IF NOT EXISTS `server_item_petskillstoneitem` (
  `name_Korea` varchar(18) NOT NULL,
  `name_Japan` varchar(17) NOT NULL,
  `name_English` varchar(42) NOT NULL,
  `name_German` varchar(42) NOT NULL,
  `name_Italian` varchar(42) NOT NULL,
  `name_Spanish` varchar(42) NOT NULL,
  `name_Portuguese` varchar(42) NOT NULL,
  `name_French` varchar(42) NOT NULL,
  `name_Turkish` varchar(42) NOT NULL,
  `name_China` varchar(42) NOT NULL,
  `name_Taiwan` varchar(18) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(19) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_대상코드` varchar(9) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_questitem`
--

CREATE TABLE IF NOT EXISTS `server_item_questitem` (
  `name_Korea` varchar(17) NOT NULL,
  `name_Japan` varchar(23) NOT NULL,
  `name_English` varchar(48) NOT NULL,
  `name_German` varchar(48) NOT NULL,
  `name_Italian` varchar(48) NOT NULL,
  `name_Spanish` varchar(48) NOT NULL,
  `name_Portuguese` varchar(48) NOT NULL,
  `name_French` varchar(48) NOT NULL,
  `name_Turkish` varchar(48) NOT NULL,
  `name_China` varchar(16) NOT NULL,
  `name_Taiwan` varchar(34) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(17) NOT NULL,
  `item_처분가격` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(2) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_questscrollitem`
--

CREATE TABLE IF NOT EXISTS `server_item_questscrollitem` (
  `name_Korea` varchar(22) NOT NULL,
  `name_Japan` varchar(27) NOT NULL,
  `name_English` varchar(57) NOT NULL,
  `name_German` varchar(57) NOT NULL,
  `name_Italian` varchar(57) NOT NULL,
  `name_Spanish` varchar(57) NOT NULL,
  `name_Portuguese` varchar(57) NOT NULL,
  `name_French` varchar(57) NOT NULL,
  `name_Turkish` varchar(57) NOT NULL,
  `name_China` varchar(20) NOT NULL,
  `name_Taiwan` varchar(20) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(15) NOT NULL,
  `item_대상코드` varchar(9) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_randomboxchangeitem`
--

CREATE TABLE IF NOT EXISTS `server_item_randomboxchangeitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(9) NOT NULL,
  `name_English` varchar(9) NOT NULL,
  `name_German` varchar(9) NOT NULL,
  `name_Italian` varchar(9) NOT NULL,
  `name_Spanish` varchar(9) NOT NULL,
  `name_Portuguese` varchar(9) NOT NULL,
  `name_French` varchar(9) NOT NULL,
  `name_Turkish` varchar(9) NOT NULL,
  `name_China` varchar(9) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(9) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_아이템등급` varchar(2) NOT NULL,
  `item_강화레벨` varchar(2) NOT NULL,
  `item_보상총개수` varchar(1) NOT NULL,
  `item_보상0` varchar(9) NOT NULL,
  `item_보상수량0` varchar(2) NOT NULL,
  `item_보상확률0` varchar(4) NOT NULL,
  `item_보상1` varchar(9) NOT NULL,
  `item_보상수량1` varchar(2) NOT NULL,
  `item_보상확률1` varchar(4) NOT NULL,
  `item_보상2` varchar(9) NOT NULL,
  `item_보상수량2` varchar(2) NOT NULL,
  `item_보상확률2` varchar(4) NOT NULL,
  `item_보상3` varchar(9) NOT NULL,
  `item_보상수량3` varchar(1) NOT NULL,
  `item_보상확률3` varchar(4) NOT NULL,
  `item_보상4` varchar(9) NOT NULL,
  `item_보상수량4` varchar(2) NOT NULL,
  `item_보상확률4` varchar(3) NOT NULL,
  `item_보상5` varchar(9) NOT NULL,
  `item_보상수량5` varchar(2) NOT NULL,
  `item_보상확률5` varchar(3) NOT NULL,
  `item_보상6` varchar(1) NOT NULL,
  `item_보상수량6` varchar(1) NOT NULL,
  `item_보상확률6` varchar(1) NOT NULL,
  `item_보상7` varchar(1) NOT NULL,
  `item_보상수량7` varchar(1) NOT NULL,
  `item_보상확률7` varchar(1) NOT NULL,
  `item_보상8` varchar(1) NOT NULL,
  `item_보상수량8` varchar(1) NOT NULL,
  `item_보상확률8` varchar(1) NOT NULL,
  `item_보상9` varchar(1) NOT NULL,
  `item_보상수량9` varchar(1) NOT NULL,
  `item_보상확률9` varchar(1) NOT NULL,
  `item_보상10` varchar(1) NOT NULL,
  `item_보상수량10` varchar(1) NOT NULL,
  `item_보상확률10` varchar(1) NOT NULL,
  `item_보상11` varchar(1) NOT NULL,
  `item_보상수량11` varchar(1) NOT NULL,
  `item_보상확률11` varchar(1) NOT NULL,
  `item_보상12` varchar(1) NOT NULL,
  `item_보상수량12` varchar(1) NOT NULL,
  `item_보상확률12` varchar(1) NOT NULL,
  `item_보상13` varchar(1) NOT NULL,
  `item_보상수량13` varchar(1) NOT NULL,
  `item_보상확률13` varchar(1) NOT NULL,
  `item_보상14` varchar(1) NOT NULL,
  `item_보상수량14` varchar(1) NOT NULL,
  `item_보상확률14` varchar(1) NOT NULL,
  `item_보상15` varchar(1) NOT NULL,
  `item_보상수량15` varchar(1) NOT NULL,
  `item_보상확률15` varchar(1) NOT NULL,
  `item_보상16` varchar(1) NOT NULL,
  `item_보상수량16` varchar(1) NOT NULL,
  `item_보상확률16` varchar(1) NOT NULL,
  `item_보상17` varchar(1) NOT NULL,
  `item_보상수량17` varchar(1) NOT NULL,
  `item_보상확률17` varchar(1) NOT NULL,
  `item_보상18` varchar(1) NOT NULL,
  `item_보상수량18` varchar(1) NOT NULL,
  `item_보상확률18` varchar(1) NOT NULL,
  `item_보상19` varchar(1) NOT NULL,
  `item_보상수량19` varchar(1) NOT NULL,
  `item_보상확률19` varchar(1) NOT NULL,
  `item_보상20` varchar(1) NOT NULL,
  `item_보상수량20` varchar(1) NOT NULL,
  `item_보상확률20` varchar(1) NOT NULL,
  `item_보상21` varchar(1) NOT NULL,
  `item_보상수량21` varchar(1) NOT NULL,
  `item_보상확률21` varchar(1) NOT NULL,
  `item_보상22` varchar(1) NOT NULL,
  `item_보상수량22` varchar(1) NOT NULL,
  `item_보상확률22` varchar(1) NOT NULL,
  `item_보상23` varchar(1) NOT NULL,
  `item_보상수량23` varchar(1) NOT NULL,
  `item_보상확률23` varchar(1) NOT NULL,
  `item_보상24` varchar(1) NOT NULL,
  `item_보상수량24` varchar(1) NOT NULL,
  `item_보상확률24` varchar(1) NOT NULL,
  `item_보상25` varchar(1) NOT NULL,
  `item_보상수량25` varchar(1) NOT NULL,
  `item_보상확률25` varchar(1) NOT NULL,
  `item_보상26` varchar(1) NOT NULL,
  `item_보상수량26` varchar(1) NOT NULL,
  `item_보상확률26` varchar(1) NOT NULL,
  `item_보상27` varchar(1) NOT NULL,
  `item_보상수량27` varchar(1) NOT NULL,
  `item_보상확률27` varchar(1) NOT NULL,
  `item_보상28` varchar(1) NOT NULL,
  `item_보상수량28` varchar(1) NOT NULL,
  `item_보상확률28` varchar(1) NOT NULL,
  `item_보상29` varchar(1) NOT NULL,
  `item_보상수량29` varchar(1) NOT NULL,
  `item_보상확률29` varchar(1) NOT NULL,
  `item_보상30` varchar(1) NOT NULL,
  `item_보상수량30` varchar(1) NOT NULL,
  `item_보상확률30` varchar(1) NOT NULL,
  `item_보상31` varchar(1) NOT NULL,
  `item_보상수량31` varchar(1) NOT NULL,
  `item_보상확률31` varchar(1) NOT NULL,
  `item_보상32` varchar(1) NOT NULL,
  `item_보상수량32` varchar(1) NOT NULL,
  `item_보상확률32` varchar(1) NOT NULL,
  `item_보상33` varchar(1) NOT NULL,
  `item_보상수량33` varchar(1) NOT NULL,
  `item_보상확률33` varchar(1) NOT NULL,
  `item_보상34` varchar(1) NOT NULL,
  `item_보상수량34` varchar(1) NOT NULL,
  `item_보상확률34` varchar(1) NOT NULL,
  `item_보상35` varchar(1) NOT NULL,
  `item_보상수량35` varchar(1) NOT NULL,
  `item_보상확률35` varchar(1) NOT NULL,
  `item_보상36` varchar(1) NOT NULL,
  `item_보상수량36` varchar(1) NOT NULL,
  `item_보상확률36` varchar(1) NOT NULL,
  `item_보상37` varchar(1) NOT NULL,
  `item_보상수량37` varchar(1) NOT NULL,
  `item_보상확률37` varchar(1) NOT NULL,
  `item_보상38` varchar(1) NOT NULL,
  `item_보상수량38` varchar(1) NOT NULL,
  `item_보상확률38` varchar(1) NOT NULL,
  `item_보상39` varchar(1) NOT NULL,
  `item_보상수량39` varchar(1) NOT NULL,
  `item_보상확률39` varchar(1) NOT NULL,
  `item_보상40` varchar(1) NOT NULL,
  `item_보상수량40` varchar(1) NOT NULL,
  `item_보상확률40` varchar(1) NOT NULL,
  `item_보상41` varchar(1) NOT NULL,
  `item_보상수량41` varchar(1) NOT NULL,
  `item_보상확률41` varchar(1) NOT NULL,
  `item_보상42` varchar(1) NOT NULL,
  `item_보상수량42` varchar(1) NOT NULL,
  `item_보상확률42` varchar(1) NOT NULL,
  `item_보상43` varchar(1) NOT NULL,
  `item_보상수량43` varchar(1) NOT NULL,
  `item_보상확률43` varchar(1) NOT NULL,
  `item_보상44` varchar(1) NOT NULL,
  `item_보상수량44` varchar(1) NOT NULL,
  `item_보상확률44` varchar(1) NOT NULL,
  `item_보상45` varchar(1) NOT NULL,
  `item_보상수량45` varchar(1) NOT NULL,
  `item_보상확률45` varchar(1) NOT NULL,
  `item_보상46` varchar(1) NOT NULL,
  `item_보상수량46` varchar(1) NOT NULL,
  `item_보상확률46` varchar(1) NOT NULL,
  `item_보상47` varchar(1) NOT NULL,
  `item_보상수량47` varchar(1) NOT NULL,
  `item_보상확률47` varchar(1) NOT NULL,
  `item_보상48` varchar(1) NOT NULL,
  `item_보상수량48` varchar(1) NOT NULL,
  `item_보상확률48` varchar(1) NOT NULL,
  `item_보상49` varchar(1) NOT NULL,
  `item_보상수량49` varchar(1) NOT NULL,
  `item_보상확률49` varchar(1) NOT NULL,
  `item_보상50` varchar(1) NOT NULL,
  `item_보상수량50` varchar(1) NOT NULL,
  `item_보상확률50` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_randomboxitem`
--

CREATE TABLE IF NOT EXISTS `server_item_randomboxitem` (
  `name_Korea` varchar(28) NOT NULL,
  `name_Japan` varchar(24) NOT NULL,
  `name_English` varchar(53) NOT NULL,
  `name_German` varchar(53) NOT NULL,
  `name_Italian` varchar(53) NOT NULL,
  `name_Spanish` varchar(53) NOT NULL,
  `name_Portuguese` varchar(53) NOT NULL,
  `name_French` varchar(53) NOT NULL,
  `name_Turkish` varchar(53) NOT NULL,
  `name_China` varchar(24) NOT NULL,
  `name_Taiwan` varchar(43) NOT NULL,
  `name_Indonesia` varchar(53) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(29) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_클래스구분` varchar(1) NOT NULL,
  `item_보상0` varchar(9) NOT NULL,
  `item_보상수량0` varchar(8) NOT NULL,
  `item_보상확률0` varchar(4) NOT NULL,
  `item_보상1` varchar(9) NOT NULL,
  `item_보상수량1` varchar(7) NOT NULL,
  `item_보상확률1` varchar(4) NOT NULL,
  `item_보상2` varchar(9) NOT NULL,
  `item_보상수량2` varchar(6) NOT NULL,
  `item_보상확률2` varchar(4) NOT NULL,
  `item_보상3` varchar(9) NOT NULL,
  `item_보상수량3` varchar(6) NOT NULL,
  `item_보상확률3` varchar(4) NOT NULL,
  `item_보상4` varchar(9) NOT NULL,
  `item_보상수량4` varchar(5) NOT NULL,
  `item_보상확률4` varchar(4) NOT NULL,
  `item_보상5` varchar(9) NOT NULL,
  `item_보상수량5` varchar(5) NOT NULL,
  `item_보상확률5` varchar(4) NOT NULL,
  `item_보상6` varchar(9) NOT NULL,
  `item_보상수량6` varchar(5) NOT NULL,
  `item_보상확률6` varchar(4) NOT NULL,
  `item_보상7` varchar(9) NOT NULL,
  `item_보상수량7` varchar(5) NOT NULL,
  `item_보상확률7` varchar(4) NOT NULL,
  `item_보상8` varchar(9) NOT NULL,
  `item_보상수량8` varchar(5) NOT NULL,
  `item_보상확률8` varchar(4) NOT NULL,
  `item_보상9` varchar(9) NOT NULL,
  `item_보상수량9` varchar(4) NOT NULL,
  `item_보상확률9` varchar(4) NOT NULL,
  `item_보상10` varchar(9) NOT NULL,
  `item_보상수량10` varchar(4) NOT NULL,
  `item_보상확률10` varchar(4) NOT NULL,
  `item_보상11` varchar(9) NOT NULL,
  `item_보상수량11` varchar(4) NOT NULL,
  `item_보상확률11` varchar(4) NOT NULL,
  `item_보상12` varchar(9) NOT NULL,
  `item_보상수량12` varchar(4) NOT NULL,
  `item_보상확률12` varchar(4) NOT NULL,
  `item_보상13` varchar(9) NOT NULL,
  `item_보상수량13` varchar(4) NOT NULL,
  `item_보상확률13` varchar(4) NOT NULL,
  `item_보상14` varchar(9) NOT NULL,
  `item_보상수량14` varchar(4) NOT NULL,
  `item_보상확률14` varchar(4) NOT NULL,
  `item_보상15` varchar(9) NOT NULL,
  `item_보상수량15` varchar(4) NOT NULL,
  `item_보상확률15` varchar(4) NOT NULL,
  `item_보상16` varchar(9) NOT NULL,
  `item_보상수량16` varchar(4) NOT NULL,
  `item_보상확률16` varchar(4) NOT NULL,
  `item_보상17` varchar(9) NOT NULL,
  `item_보상수량17` varchar(4) NOT NULL,
  `item_보상확률17` varchar(4) NOT NULL,
  `item_보상18` varchar(9) NOT NULL,
  `item_보상수량18` varchar(2) NOT NULL,
  `item_보상확률18` varchar(4) NOT NULL,
  `item_보상19` varchar(9) NOT NULL,
  `item_보상수량19` varchar(2) NOT NULL,
  `item_보상확률19` varchar(4) NOT NULL,
  `item_보상20` varchar(9) NOT NULL,
  `item_보상수량20` varchar(2) NOT NULL,
  `item_보상확률20` varchar(4) NOT NULL,
  `item_보상21` varchar(9) NOT NULL,
  `item_보상수량21` varchar(2) NOT NULL,
  `item_보상확률21` varchar(4) NOT NULL,
  `item_보상22` varchar(9) NOT NULL,
  `item_보상수량22` varchar(2) NOT NULL,
  `item_보상확률22` varchar(3) NOT NULL,
  `item_보상23` varchar(9) NOT NULL,
  `item_보상수량23` varchar(2) NOT NULL,
  `item_보상확률23` varchar(3) NOT NULL,
  `item_보상24` varchar(9) NOT NULL,
  `item_보상수량24` varchar(2) NOT NULL,
  `item_보상확률24` varchar(4) NOT NULL,
  `item_보상25` varchar(9) NOT NULL,
  `item_보상수량25` varchar(2) NOT NULL,
  `item_보상확률25` varchar(4) NOT NULL,
  `item_보상26` varchar(9) NOT NULL,
  `item_보상수량26` varchar(2) NOT NULL,
  `item_보상확률26` varchar(4) NOT NULL,
  `item_보상27` varchar(9) NOT NULL,
  `item_보상수량27` varchar(2) NOT NULL,
  `item_보상확률27` varchar(4) NOT NULL,
  `item_보상28` varchar(9) NOT NULL,
  `item_보상수량28` varchar(2) NOT NULL,
  `item_보상확률28` varchar(4) NOT NULL,
  `item_보상29` varchar(9) NOT NULL,
  `item_보상수량29` varchar(2) NOT NULL,
  `item_보상확률29` varchar(4) NOT NULL,
  `item_보상30` varchar(9) NOT NULL,
  `item_보상수량30` varchar(2) NOT NULL,
  `item_보상확률30` varchar(3) NOT NULL,
  `item_보상31` varchar(9) NOT NULL,
  `item_보상수량31` varchar(2) NOT NULL,
  `item_보상확률31` varchar(3) NOT NULL,
  `item_보상32` varchar(9) NOT NULL,
  `item_보상수량32` varchar(2) NOT NULL,
  `item_보상확률32` varchar(3) NOT NULL,
  `item_보상33` varchar(9) NOT NULL,
  `item_보상수량33` varchar(2) NOT NULL,
  `item_보상확률33` varchar(3) NOT NULL,
  `item_보상34` varchar(9) NOT NULL,
  `item_보상수량34` varchar(2) NOT NULL,
  `item_보상확률34` varchar(3) NOT NULL,
  `item_보상35` varchar(9) NOT NULL,
  `item_보상수량35` varchar(2) NOT NULL,
  `item_보상확률35` varchar(3) NOT NULL,
  `item_보상36` varchar(9) NOT NULL,
  `item_보상수량36` varchar(2) NOT NULL,
  `item_보상확률36` varchar(3) NOT NULL,
  `item_보상37` varchar(9) NOT NULL,
  `item_보상수량37` varchar(2) NOT NULL,
  `item_보상확률37` varchar(3) NOT NULL,
  `item_보상38` varchar(9) NOT NULL,
  `item_보상수량38` varchar(1) NOT NULL,
  `item_보상확률38` varchar(3) NOT NULL,
  `item_보상39` varchar(9) NOT NULL,
  `item_보상수량39` varchar(1) NOT NULL,
  `item_보상확률39` varchar(3) NOT NULL,
  `item_보상40` varchar(9) NOT NULL,
  `item_보상수량40` varchar(2) NOT NULL,
  `item_보상확률40` varchar(3) NOT NULL,
  `item_보상41` varchar(9) NOT NULL,
  `item_보상수량41` varchar(2) NOT NULL,
  `item_보상확률41` varchar(3) NOT NULL,
  `item_보상42` varchar(9) NOT NULL,
  `item_보상수량42` varchar(2) NOT NULL,
  `item_보상확률42` varchar(3) NOT NULL,
  `item_보상43` varchar(9) NOT NULL,
  `item_보상수량43` varchar(3) NOT NULL,
  `item_보상확률43` varchar(3) NOT NULL,
  `item_보상44` varchar(9) NOT NULL,
  `item_보상수량44` varchar(2) NOT NULL,
  `item_보상확률44` varchar(3) NOT NULL,
  `item_보상45` varchar(9) NOT NULL,
  `item_보상수량45` varchar(2) NOT NULL,
  `item_보상확률45` varchar(3) NOT NULL,
  `item_보상46` varchar(9) NOT NULL,
  `item_보상수량46` varchar(2) NOT NULL,
  `item_보상확률46` varchar(3) NOT NULL,
  `item_보상47` varchar(9) NOT NULL,
  `item_보상수량47` varchar(2) NOT NULL,
  `item_보상확률47` varchar(3) NOT NULL,
  `item_보상48` varchar(9) NOT NULL,
  `item_보상수량48` varchar(2) NOT NULL,
  `item_보상확률48` varchar(3) NOT NULL,
  `item_보상49` varchar(9) NOT NULL,
  `item_보상수량49` varchar(2) NOT NULL,
  `item_보상확률49` varchar(3) NOT NULL,
  `item_보상50` varchar(9) NOT NULL,
  `item_보상수량50` varchar(1) NOT NULL,
  `item_보상확률50` varchar(3) NOT NULL,
  `item_보상51` varchar(9) NOT NULL,
  `item_보상수량51` varchar(1) NOT NULL,
  `item_보상확률51` varchar(3) NOT NULL,
  `item_보상52` varchar(9) NOT NULL,
  `item_보상수량52` varchar(5) NOT NULL,
  `item_보상확률52` varchar(3) NOT NULL,
  `item_보상53` varchar(9) NOT NULL,
  `item_보상수량53` varchar(5) NOT NULL,
  `item_보상확률53` varchar(3) NOT NULL,
  `item_보상54` varchar(9) NOT NULL,
  `item_보상수량54` varchar(5) NOT NULL,
  `item_보상확률54` varchar(3) NOT NULL,
  `item_보상55` varchar(9) NOT NULL,
  `item_보상수량55` varchar(5) NOT NULL,
  `item_보상확률55` varchar(3) NOT NULL,
  `item_보상56` varchar(9) NOT NULL,
  `item_보상수량56` varchar(5) NOT NULL,
  `item_보상확률56` varchar(3) NOT NULL,
  `item_보상57` varchar(9) NOT NULL,
  `item_보상수량57` varchar(4) NOT NULL,
  `item_보상확률57` varchar(4) NOT NULL,
  `item_보상58` varchar(9) NOT NULL,
  `item_보상수량58` varchar(4) NOT NULL,
  `item_보상확률58` varchar(4) NOT NULL,
  `item_보상59` varchar(9) NOT NULL,
  `item_보상수량59` varchar(4) NOT NULL,
  `item_보상확률59` varchar(4) NOT NULL,
  `item_보상60` varchar(1) NOT NULL,
  `item_보상수량60` varchar(1) NOT NULL,
  `item_보상확률60` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_recipeitem`
--

CREATE TABLE IF NOT EXISTS `server_item_recipeitem` (
  `name_Korea` varchar(21) NOT NULL,
  `name_Japan` varchar(30) NOT NULL,
  `name_English` varchar(51) NOT NULL,
  `name_German` varchar(51) NOT NULL,
  `name_Italian` varchar(51) NOT NULL,
  `name_Spanish` varchar(51) NOT NULL,
  `name_Portuguese` varchar(51) NOT NULL,
  `name_French` varchar(51) NOT NULL,
  `name_Turkish` varchar(51) NOT NULL,
  `name_China` varchar(26) NOT NULL,
  `name_Taiwan` varchar(51) NOT NULL,
  `name_Indonesia` varchar(51) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(18) NOT NULL,
  `item_결과물코드` varchar(9) NOT NULL,
  `item_결과물수량` varchar(1) NOT NULL,
  `item_실패결과물코드` varchar(1) NOT NULL,
  `item_실패결과물수량` varchar(1) NOT NULL,
  `item_재료1` varchar(9) NOT NULL,
  `item_필요량1` varchar(3) NOT NULL,
  `item_재료2` varchar(9) NOT NULL,
  `item_필요량2` varchar(2) NOT NULL,
  `item_재료3` varchar(9) NOT NULL,
  `item_필요량3` varchar(3) NOT NULL,
  `item_재료4` varchar(9) NOT NULL,
  `item_필요량4` varchar(2) NOT NULL,
  `item_재료5` varchar(9) NOT NULL,
  `item_필요량5` varchar(2) NOT NULL,
  `item_재료6` varchar(9) NOT NULL,
  `item_필요량6` varchar(2) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_returnstoneitem`
--

CREATE TABLE IF NOT EXISTS `server_item_returnstoneitem` (
  `name_Korea` varchar(1) NOT NULL,
  `name_Japan` varchar(1) NOT NULL,
  `name_English` varchar(1) NOT NULL,
  `name_German` varchar(1) NOT NULL,
  `name_Italian` varchar(1) NOT NULL,
  `name_Spanish` varchar(1) NOT NULL,
  `name_Portuguese` varchar(1) NOT NULL,
  `name_French` varchar(1) NOT NULL,
  `name_Turkish` varchar(1) NOT NULL,
  `name_China` varchar(1) NOT NULL,
  `name_Taiwan` varchar(1) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(1) NOT NULL,
  `item_이름` varchar(1) NOT NULL,
  `item_사용성별` varchar(1) NOT NULL,
  `item_사용직업` varchar(1) NOT NULL,
  `item_쿨타임밀초` varchar(1) NOT NULL,
  `item_타입` varchar(1) NOT NULL,
  `item_성능` varchar(1) NOT NULL,
  `item_판매가격` varchar(1) NOT NULL,
  `item_처분가격` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_ridingpetitem`
--

CREATE TABLE IF NOT EXISTS `server_item_ridingpetitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(9) NOT NULL,
  `name_English` varchar(21) NOT NULL,
  `name_German` varchar(21) NOT NULL,
  `name_Italian` varchar(21) NOT NULL,
  `name_Spanish` varchar(21) NOT NULL,
  `name_Portuguese` varchar(21) NOT NULL,
  `name_French` varchar(21) NOT NULL,
  `name_Turkish` varchar(21) NOT NULL,
  `name_China` varchar(21) NOT NULL,
  `name_Taiwan` varchar(21) NOT NULL,
  `name_Indonesia` varchar(21) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(9) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(5) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_육상최소레벨` varchar(1) NOT NULL,
  `item_해상최소레벨` varchar(1) NOT NULL,
  `item_쿨타임계열` varchar(1) NOT NULL,
  `item_쿨타임밀초` varchar(4) NOT NULL,
  `item_캐스팅시간밀초` varchar(4) NOT NULL,
  `item_타입` varchar(2) NOT NULL,
  `item_성능` varchar(10) NOT NULL,
  `item_스킬코드` varchar(8) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_sealhelpbreakitem`
--

CREATE TABLE IF NOT EXISTS `server_item_sealhelpbreakitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(7) NOT NULL,
  `name_English` varchar(19) NOT NULL,
  `name_German` varchar(19) NOT NULL,
  `name_Italian` varchar(19) NOT NULL,
  `name_Spanish` varchar(19) NOT NULL,
  `name_Portuguese` varchar(19) NOT NULL,
  `name_French` varchar(19) NOT NULL,
  `name_Turkish` varchar(19) NOT NULL,
  `name_China` varchar(17) NOT NULL,
  `name_Taiwan` varchar(17) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(9) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_타입구분` varchar(1) NOT NULL,
  `item_아이템등급` varchar(1) NOT NULL,
  `item_봉인해제연산자` varchar(1) NOT NULL,
  `item_봉인해제성공률` varchar(10) NOT NULL,
  `item_옵션등급상향연산자` varchar(1) NOT NULL,
  `item_상향수치` varchar(1) NOT NULL,
  `item_목표옵션코드` varchar(3) NOT NULL,
  `item_목표옵션증가수치` varchar(1) NOT NULL,
  `item_판매가격` varchar(1) NOT NULL,
  `item_처분가격` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(3) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shellitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shellitem` (
  `name_Korea` varchar(10) NOT NULL,
  `name_Japan` varchar(8) NOT NULL,
  `name_English` varchar(38) NOT NULL,
  `name_German` varchar(38) NOT NULL,
  `name_Italian` varchar(38) NOT NULL,
  `name_Spanish` varchar(38) NOT NULL,
  `name_Portuguese` varchar(38) NOT NULL,
  `name_French` varchar(38) NOT NULL,
  `name_Turkish` varchar(38) NOT NULL,
  `name_China` varchar(10) NOT NULL,
  `name_Taiwan` varchar(8) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(10) NOT NULL,
  `item_사용가능무기` varchar(1) NOT NULL,
  `item_제한레벨` varchar(2) NOT NULL,
  `item_최대탄수` varchar(3) NOT NULL,
  `item_최대중복개수` varchar(4) NOT NULL,
  `item_물공력` varchar(2) NOT NULL,
  `item_속성타입` varchar(1) NOT NULL,
  `item_속공력` varchar(1) NOT NULL,
  `item_추가사거리` varchar(3) NOT NULL,
  `item_추가밸런스` varchar(10) NOT NULL,
  `item_폭발반경` varchar(2) NOT NULL,
  `item_지속시간밀초` varchar(1) NOT NULL,
  `item_지속효과코드` varchar(10) NOT NULL,
  `item_수치연산자` varchar(1) NOT NULL,
  `item_지속효과값` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shielditem`
--

CREATE TABLE IF NOT EXISTS `server_item_shielditem` (
  `name_Korea` varchar(13) NOT NULL,
  `name_Japan` varchar(14) NOT NULL,
  `name_English` varchar(30) NOT NULL,
  `name_German` varchar(30) NOT NULL,
  `name_Italian` varchar(30) NOT NULL,
  `name_Spanish` varchar(30) NOT NULL,
  `name_Portuguese` varchar(30) NOT NULL,
  `name_French` varchar(30) NOT NULL,
  `name_Turkish` varchar(30) NOT NULL,
  `name_China` varchar(21) NOT NULL,
  `name_Taiwan` varchar(21) NOT NULL,
  `name_Indonesia` varchar(30) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(13) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(2) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_업그레이드코드` varchar(1) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(1) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(1) NOT NULL,
  `item_최대내구도` varchar(6) NOT NULL,
  `item_최소물공력` varchar(1) NOT NULL,
  `item_최대물공력` varchar(1) NOT NULL,
  `item_최소마공력` varchar(1) NOT NULL,
  `item_최대마공력` varchar(1) NOT NULL,
  `item_물방력` varchar(4) NOT NULL,
  `item_물공쿨타임밀초` varchar(3) NOT NULL,
  `item_물공최소거리` varchar(1) NOT NULL,
  `item_물공최대거리` varchar(1) NOT NULL,
  `item_마공케스팅타임밀초` varchar(1) NOT NULL,
  `item_마항력` varchar(3) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_마공명` varchar(1) NOT NULL,
  `item_물공피` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_물공모션타임밀초1` varchar(1) NOT NULL,
  `item_물공모션타임밀초2` varchar(1) NOT NULL,
  `item_크리공격모션타임밀초` varchar(1) NOT NULL,
  `item_최대업글단계` varchar(1) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(10) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(9) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shipanchoritem`
--

CREATE TABLE IF NOT EXISTS `server_item_shipanchoritem` (
  `name_Korea` varchar(11) NOT NULL,
  `name_Japan` varchar(9) NOT NULL,
  `name_English` varchar(54) NOT NULL,
  `name_German` varchar(54) NOT NULL,
  `name_Italian` varchar(54) NOT NULL,
  `name_Spanish` varchar(54) NOT NULL,
  `name_Portuguese` varchar(54) NOT NULL,
  `name_French` varchar(54) NOT NULL,
  `name_Turkish` varchar(54) NOT NULL,
  `name_China` varchar(13) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(11) NOT NULL,
  `item_클래스` varchar(5) NOT NULL,
  `item_장착파트` varchar(2) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(4) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(1) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(1) NOT NULL,
  `item_유효거리` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_장전속도` varchar(1) NOT NULL,
  `item_공격지연밀초` varchar(1) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(1) NOT NULL,
  `item_집탄범위` varchar(1) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_방탄력` varchar(1) NOT NULL,
  `item_선체가로길이` varchar(1) NOT NULL,
  `item_선체세로길이` varchar(1) NOT NULL,
  `item_HP` varchar(1) NOT NULL,
  `item_필요선원수` varchar(1) NOT NULL,
  `item_횡범성능` varchar(1) NOT NULL,
  `item_종범성능` varchar(1) NOT NULL,
  `item_가속력` varchar(1) NOT NULL,
  `item_정선력` varchar(10) NOT NULL,
  `item_선회력` varchar(10) NOT NULL,
  `item_EN` varchar(1) NOT NULL,
  `item_EN회복` varchar(1) NOT NULL,
  `item_EN소모` varchar(1) NOT NULL,
  `item_벨런스` varchar(1) NOT NULL,
  `item_내구도` varchar(4) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_튜닝가격` varchar(10) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_효과값_1` varchar(1) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_효과값_2` varchar(1) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shipbodyitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shipbodyitem` (
  `name_Korea` varchar(14) NOT NULL,
  `name_Japan` varchar(16) NOT NULL,
  `name_English` varchar(31) NOT NULL,
  `name_German` varchar(31) NOT NULL,
  `name_Italian` varchar(31) NOT NULL,
  `name_Spanish` varchar(31) NOT NULL,
  `name_Portuguese` varchar(31) NOT NULL,
  `name_French` varchar(31) NOT NULL,
  `name_Turkish` varchar(31) NOT NULL,
  `name_China` varchar(9) NOT NULL,
  `name_Taiwan` varchar(6) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(14) NOT NULL,
  `item_클래스` varchar(1) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(1) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(1) NOT NULL,
  `item_유효거리` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_장전속도` varchar(1) NOT NULL,
  `item_공격지연밀초` varchar(1) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(1) NOT NULL,
  `item_집탄범위` varchar(1) NOT NULL,
  `item_물방력` varchar(4) NOT NULL,
  `item_방탄력` varchar(3) NOT NULL,
  `item_선체가로길이` varchar(3) NOT NULL,
  `item_선체세로길이` varchar(3) NOT NULL,
  `item_HP` varchar(5) NOT NULL,
  `item_필요선원수` varchar(3) NOT NULL,
  `item_횡범성능` varchar(1) NOT NULL,
  `item_종범성능` varchar(1) NOT NULL,
  `item_가속력` varchar(1) NOT NULL,
  `item_정선력` varchar(1) NOT NULL,
  `item_선회력` varchar(1) NOT NULL,
  `item_EN` varchar(1) NOT NULL,
  `item_EN회복` varchar(1) NOT NULL,
  `item_EN소모` varchar(1) NOT NULL,
  `item_벨런스` varchar(1) NOT NULL,
  `item_내구도` varchar(3) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_튜닝가격` varchar(10) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_효과값_1` varchar(1) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_효과값_2` varchar(1) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shipcweaponitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shipcweaponitem` (
  `name_Korea` varchar(18) NOT NULL,
  `name_Japan` varchar(37) NOT NULL,
  `name_English` varchar(43) NOT NULL,
  `name_German` varchar(43) NOT NULL,
  `name_Italian` varchar(43) NOT NULL,
  `name_Spanish` varchar(43) NOT NULL,
  `name_Portuguese` varchar(43) NOT NULL,
  `name_French` varchar(43) NOT NULL,
  `name_Turkish` varchar(43) NOT NULL,
  `name_China` varchar(37) NOT NULL,
  `name_Taiwan` varchar(37) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(19) NOT NULL,
  `item_클래스` varchar(1) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(4) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(4) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(5) NOT NULL,
  `item_유효거리` varchar(1) NOT NULL,
  `item_크리티컬` varchar(2) NOT NULL,
  `item_장전속도` varchar(5) NOT NULL,
  `item_공격지연밀초` varchar(4) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(4) NOT NULL,
  `item_집탄범위` varchar(4) NOT NULL,
  `item_물방력` varchar(10) NOT NULL,
  `item_방탄력` varchar(10) NOT NULL,
  `item_선체가로길이` varchar(1) NOT NULL,
  `item_선체세로길이` varchar(1) NOT NULL,
  `item_HP` varchar(10) NOT NULL,
  `item_필요선원수` varchar(1) NOT NULL,
  `item_횡범성능` varchar(3) NOT NULL,
  `item_종범성능` varchar(2) NOT NULL,
  `item_가속력` varchar(1) NOT NULL,
  `item_정선력` varchar(1) NOT NULL,
  `item_선회력` varchar(1) NOT NULL,
  `item_EN` varchar(4) NOT NULL,
  `item_EN회복` varchar(1) NOT NULL,
  `item_EN소모` varchar(3) NOT NULL,
  `item_벨런스` varchar(1) NOT NULL,
  `item_내구도` varchar(3) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_튜닝가격` varchar(10) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shipfigureitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shipfigureitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(7) NOT NULL,
  `name_English` varchar(32) NOT NULL,
  `name_German` varchar(32) NOT NULL,
  `name_Italian` varchar(32) NOT NULL,
  `name_Spanish` varchar(32) NOT NULL,
  `name_Portuguese` varchar(32) NOT NULL,
  `name_French` varchar(32) NOT NULL,
  `name_Turkish` varchar(32) NOT NULL,
  `name_China` varchar(11) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(9) NOT NULL,
  `item_클래스` varchar(5) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(1) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(1) NOT NULL,
  `item_유효거리` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_장전속도` varchar(1) NOT NULL,
  `item_공격지연밀초` varchar(1) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(1) NOT NULL,
  `item_집탄범위` varchar(1) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_방탄력` varchar(2) NOT NULL,
  `item_선체가로길이` varchar(1) NOT NULL,
  `item_선체세로길이` varchar(1) NOT NULL,
  `item_HP` varchar(1) NOT NULL,
  `item_필요선원수` varchar(1) NOT NULL,
  `item_횡범성능` varchar(1) NOT NULL,
  `item_종범성능` varchar(1) NOT NULL,
  `item_가속력` varchar(1) NOT NULL,
  `item_정선력` varchar(1) NOT NULL,
  `item_선회력` varchar(1) NOT NULL,
  `item_EN` varchar(1) NOT NULL,
  `item_EN회복` varchar(1) NOT NULL,
  `item_EN소모` varchar(1) NOT NULL,
  `item_벨런스` varchar(1) NOT NULL,
  `item_내구도` varchar(3) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_튜닝가격` varchar(10) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_효과값_1` varchar(1) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_효과값_2` varchar(1) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shipflagitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shipflagitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(7) NOT NULL,
  `name_English` varchar(28) NOT NULL,
  `name_German` varchar(28) NOT NULL,
  `name_Italian` varchar(28) NOT NULL,
  `name_Spanish` varchar(28) NOT NULL,
  `name_Portuguese` varchar(28) NOT NULL,
  `name_French` varchar(28) NOT NULL,
  `name_Turkish` varchar(28) NOT NULL,
  `name_China` varchar(8) NOT NULL,
  `name_Taiwan` varchar(10) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(9) NOT NULL,
  `item_클래스` varchar(5) NOT NULL,
  `item_장착파트` varchar(2) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(4) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(1) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(1) NOT NULL,
  `item_유효거리` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_장전속도` varchar(1) NOT NULL,
  `item_공격지연밀초` varchar(1) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(1) NOT NULL,
  `item_집탄범위` varchar(1) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_방탄력` varchar(1) NOT NULL,
  `item_선체가로길이` varchar(1) NOT NULL,
  `item_선체세로길이` varchar(1) NOT NULL,
  `item_HP` varchar(1) NOT NULL,
  `item_필요선원수` varchar(1) NOT NULL,
  `item_횡범성능` varchar(1) NOT NULL,
  `item_종범성능` varchar(1) NOT NULL,
  `item_가속력` varchar(1) NOT NULL,
  `item_정선력` varchar(1) NOT NULL,
  `item_선회력` varchar(1) NOT NULL,
  `item_EN` varchar(1) NOT NULL,
  `item_EN회복` varchar(1) NOT NULL,
  `item_EN소모` varchar(1) NOT NULL,
  `item_벨런스` varchar(1) NOT NULL,
  `item_내구도` varchar(3) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_튜닝가격` varchar(10) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_효과값_1` varchar(1) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_효과값_2` varchar(1) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shipfrontitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shipfrontitem` (
  `name_Korea` varchar(12) NOT NULL,
  `name_Japan` varchar(15) NOT NULL,
  `name_English` varchar(33) NOT NULL,
  `name_German` varchar(33) NOT NULL,
  `name_Italian` varchar(33) NOT NULL,
  `name_Spanish` varchar(33) NOT NULL,
  `name_Portuguese` varchar(33) NOT NULL,
  `name_French` varchar(33) NOT NULL,
  `name_Turkish` varchar(33) NOT NULL,
  `name_China` varchar(7) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(12) NOT NULL,
  `item_클래스` varchar(1) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(1) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(1) NOT NULL,
  `item_유효거리` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_장전속도` varchar(1) NOT NULL,
  `item_공격지연밀초` varchar(1) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(1) NOT NULL,
  `item_집탄범위` varchar(1) NOT NULL,
  `item_물방력` varchar(3) NOT NULL,
  `item_방탄력` varchar(2) NOT NULL,
  `item_선체가로길이` varchar(1) NOT NULL,
  `item_선체세로길이` varchar(1) NOT NULL,
  `item_HP` varchar(4) NOT NULL,
  `item_필요선원수` varchar(1) NOT NULL,
  `item_횡범성능` varchar(1) NOT NULL,
  `item_종범성능` varchar(1) NOT NULL,
  `item_가속력` varchar(1) NOT NULL,
  `item_정선력` varchar(1) NOT NULL,
  `item_선회력` varchar(1) NOT NULL,
  `item_EN` varchar(1) NOT NULL,
  `item_EN회복` varchar(1) NOT NULL,
  `item_EN소모` varchar(1) NOT NULL,
  `item_벨런스` varchar(10) NOT NULL,
  `item_내구도` varchar(3) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_튜닝가격` varchar(10) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_효과값_1` varchar(1) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_효과값_2` varchar(1) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shipheadmastitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shipheadmastitem` (
  `name_Korea` varchar(16) NOT NULL,
  `name_Japan` varchar(15) NOT NULL,
  `name_English` varchar(45) NOT NULL,
  `name_German` varchar(45) NOT NULL,
  `name_Italian` varchar(45) NOT NULL,
  `name_Spanish` varchar(45) NOT NULL,
  `name_Portuguese` varchar(45) NOT NULL,
  `name_French` varchar(45) NOT NULL,
  `name_Turkish` varchar(45) NOT NULL,
  `name_China` varchar(15) NOT NULL,
  `name_Taiwan` varchar(11) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(16) NOT NULL,
  `item_클래스` varchar(1) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(1) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(1) NOT NULL,
  `item_유효거리` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_장전속도` varchar(1) NOT NULL,
  `item_공격지연밀초` varchar(1) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(1) NOT NULL,
  `item_집탄범위` varchar(1) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_방탄력` varchar(1) NOT NULL,
  `item_선체가로길이` varchar(1) NOT NULL,
  `item_선체세로길이` varchar(1) NOT NULL,
  `item_HP` varchar(1) NOT NULL,
  `item_필요선원수` varchar(1) NOT NULL,
  `item_횡범성능` varchar(3) NOT NULL,
  `item_종범성능` varchar(3) NOT NULL,
  `item_가속력` varchar(1) NOT NULL,
  `item_정선력` varchar(1) NOT NULL,
  `item_선회력` varchar(10) NOT NULL,
  `item_EN` varchar(1) NOT NULL,
  `item_EN회복` varchar(1) NOT NULL,
  `item_EN소모` varchar(1) NOT NULL,
  `item_벨런스` varchar(1) NOT NULL,
  `item_내구도` varchar(3) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_튜닝가격` varchar(10) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_효과값_1` varchar(1) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_효과값_2` varchar(1) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shipmagicstoneitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shipmagicstoneitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(7) NOT NULL,
  `name_English` varchar(41) NOT NULL,
  `name_German` varchar(41) NOT NULL,
  `name_Italian` varchar(41) NOT NULL,
  `name_Spanish` varchar(41) NOT NULL,
  `name_Portuguese` varchar(41) NOT NULL,
  `name_French` varchar(41) NOT NULL,
  `name_Turkish` varchar(41) NOT NULL,
  `name_China` varchar(16) NOT NULL,
  `name_Taiwan` varchar(10) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(9) NOT NULL,
  `item_클래스` varchar(5) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(4) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(1) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(1) NOT NULL,
  `item_유효거리` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_장전속도` varchar(1) NOT NULL,
  `item_공격지연밀초` varchar(1) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(1) NOT NULL,
  `item_집탄범위` varchar(1) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_방탄력` varchar(1) NOT NULL,
  `item_선체가로길이` varchar(1) NOT NULL,
  `item_선체세로길이` varchar(1) NOT NULL,
  `item_HP` varchar(1) NOT NULL,
  `item_필요선원수` varchar(1) NOT NULL,
  `item_횡범성능` varchar(1) NOT NULL,
  `item_종범성능` varchar(1) NOT NULL,
  `item_가속력` varchar(1) NOT NULL,
  `item_정선력` varchar(1) NOT NULL,
  `item_선회력` varchar(1) NOT NULL,
  `item_EN` varchar(4) NOT NULL,
  `item_EN회복` varchar(3) NOT NULL,
  `item_EN소모` varchar(1) NOT NULL,
  `item_벨런스` varchar(1) NOT NULL,
  `item_내구도` varchar(3) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_튜닝가격` varchar(10) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_효과값_1` varchar(1) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_효과값_2` varchar(1) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shipmainmastitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shipmainmastitem` (
  `name_Korea` varchar(16) NOT NULL,
  `name_Japan` varchar(17) NOT NULL,
  `name_English` varchar(52) NOT NULL,
  `name_German` varchar(52) NOT NULL,
  `name_Italian` varchar(52) NOT NULL,
  `name_Spanish` varchar(52) NOT NULL,
  `name_Portuguese` varchar(52) NOT NULL,
  `name_French` varchar(52) NOT NULL,
  `name_Turkish` varchar(52) NOT NULL,
  `name_China` varchar(15) NOT NULL,
  `name_Taiwan` varchar(15) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(16) NOT NULL,
  `item_클래스` varchar(5) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(1) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(1) NOT NULL,
  `item_유효거리` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_장전속도` varchar(1) NOT NULL,
  `item_공격지연밀초` varchar(1) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(1) NOT NULL,
  `item_집탄범위` varchar(1) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_방탄력` varchar(1) NOT NULL,
  `item_선체가로길이` varchar(1) NOT NULL,
  `item_선체세로길이` varchar(1) NOT NULL,
  `item_HP` varchar(1) NOT NULL,
  `item_필요선원수` varchar(1) NOT NULL,
  `item_횡범성능` varchar(3) NOT NULL,
  `item_종범성능` varchar(3) NOT NULL,
  `item_가속력` varchar(10) NOT NULL,
  `item_정선력` varchar(10) NOT NULL,
  `item_선회력` varchar(10) NOT NULL,
  `item_EN` varchar(1) NOT NULL,
  `item_EN회복` varchar(1) NOT NULL,
  `item_EN소모` varchar(1) NOT NULL,
  `item_벨런스` varchar(1) NOT NULL,
  `item_내구도` varchar(3) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_튜닝가격` varchar(10) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_효과값_1` varchar(1) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_효과값_2` varchar(1) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shipnweaponitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shipnweaponitem` (
  `name_Korea` varchar(17) NOT NULL,
  `name_Japan` varchar(32) NOT NULL,
  `name_English` varchar(34) NOT NULL,
  `name_German` varchar(34) NOT NULL,
  `name_Italian` varchar(34) NOT NULL,
  `name_Spanish` varchar(34) NOT NULL,
  `name_Portuguese` varchar(34) NOT NULL,
  `name_French` varchar(37) NOT NULL,
  `name_Turkish` varchar(34) NOT NULL,
  `name_China` varchar(32) NOT NULL,
  `name_Taiwan` varchar(32) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(18) NOT NULL,
  `item_클래스` varchar(5) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(4) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(3) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(5) NOT NULL,
  `item_유효거리` varchar(5) NOT NULL,
  `item_크리티컬` varchar(2) NOT NULL,
  `item_장전속도` varchar(4) NOT NULL,
  `item_공격지연밀초` varchar(1) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(4) NOT NULL,
  `item_집탄범위` varchar(3) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_방탄력` varchar(1) NOT NULL,
  `item_선체가로길이` varchar(1) NOT NULL,
  `item_선체세로길이` varchar(1) NOT NULL,
  `item_HP` varchar(1) NOT NULL,
  `item_필요선원수` varchar(1) NOT NULL,
  `item_횡범성능` varchar(1) NOT NULL,
  `item_종범성능` varchar(1) NOT NULL,
  `item_가속력` varchar(1) NOT NULL,
  `item_정선력` varchar(1) NOT NULL,
  `item_선회력` varchar(1) NOT NULL,
  `item_EN` varchar(1) NOT NULL,
  `item_EN회복` varchar(1) NOT NULL,
  `item_EN소모` varchar(1) NOT NULL,
  `item_벨런스` varchar(10) NOT NULL,
  `item_내구도` varchar(3) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_튜닝가격` varchar(10) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_효과값_4` varchar(10) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shiprearitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shiprearitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(9) NOT NULL,
  `name_English` varchar(9) NOT NULL,
  `name_German` varchar(9) NOT NULL,
  `name_Italian` varchar(9) NOT NULL,
  `name_Spanish` varchar(9) NOT NULL,
  `name_Portuguese` varchar(9) NOT NULL,
  `name_French` varchar(9) NOT NULL,
  `name_Turkish` varchar(9) NOT NULL,
  `name_China` varchar(9) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(9) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(2) NOT NULL,
  `item_클래스` varchar(1) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(1) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(1) NOT NULL,
  `item_유효거리` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_장전속도` varchar(1) NOT NULL,
  `item_공격지연밀초` varchar(1) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(1) NOT NULL,
  `item_집탄범위` varchar(1) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_방탄력` varchar(1) NOT NULL,
  `item_선체가로길이` varchar(1) NOT NULL,
  `item_선체세로길이` varchar(1) NOT NULL,
  `item_HP` varchar(1) NOT NULL,
  `item_필요선원수` varchar(1) NOT NULL,
  `item_횡범성능` varchar(1) NOT NULL,
  `item_종범성능` varchar(1) NOT NULL,
  `item_가속력` varchar(1) NOT NULL,
  `item_정선력` varchar(1) NOT NULL,
  `item_선회력` varchar(1) NOT NULL,
  `item_EN` varchar(1) NOT NULL,
  `item_EN회복` varchar(1) NOT NULL,
  `item_EN소모` varchar(1) NOT NULL,
  `item_벨런스` varchar(1) NOT NULL,
  `item_내구도` varchar(1) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(1) NOT NULL,
  `item_처분가격` varchar(1) NOT NULL,
  `item_튜닝가격` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(1) NOT NULL,
  `item_효과코드_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(1) NOT NULL,
  `item_효과코드_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shiptailmastitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shiptailmastitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(9) NOT NULL,
  `name_English` varchar(9) NOT NULL,
  `name_German` varchar(9) NOT NULL,
  `name_Italian` varchar(9) NOT NULL,
  `name_Spanish` varchar(9) NOT NULL,
  `name_Portuguese` varchar(9) NOT NULL,
  `name_French` varchar(9) NOT NULL,
  `name_Turkish` varchar(9) NOT NULL,
  `name_China` varchar(9) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(9) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(2) NOT NULL,
  `item_클래스` varchar(1) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_타입` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_공격력` varchar(1) NOT NULL,
  `item_폭발력` varchar(1) NOT NULL,
  `item_충돌력` varchar(1) NOT NULL,
  `item_관통력` varchar(1) NOT NULL,
  `item_파괴력` varchar(1) NOT NULL,
  `item_최대거리` varchar(1) NOT NULL,
  `item_유효거리` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_장전속도` varchar(1) NOT NULL,
  `item_공격지연밀초` varchar(1) NOT NULL,
  `item_전포수` varchar(1) NOT NULL,
  `item_측포수` varchar(1) NOT NULL,
  `item_탄속` varchar(1) NOT NULL,
  `item_집탄범위` varchar(1) NOT NULL,
  `item_물방력` varchar(1) NOT NULL,
  `item_방탄력` varchar(1) NOT NULL,
  `item_선체가로길이` varchar(1) NOT NULL,
  `item_선체세로길이` varchar(1) NOT NULL,
  `item_HP` varchar(1) NOT NULL,
  `item_필요선원수` varchar(1) NOT NULL,
  `item_횡범성능` varchar(1) NOT NULL,
  `item_종범성능` varchar(1) NOT NULL,
  `item_가속력` varchar(1) NOT NULL,
  `item_정선력` varchar(1) NOT NULL,
  `item_선회력` varchar(1) NOT NULL,
  `item_EN` varchar(1) NOT NULL,
  `item_EN회복` varchar(1) NOT NULL,
  `item_EN소모` varchar(1) NOT NULL,
  `item_벨런스` varchar(1) NOT NULL,
  `item_내구도` varchar(1) NOT NULL,
  `item_폭발저항` varchar(1) NOT NULL,
  `item_충돌저항` varchar(1) NOT NULL,
  `item_관통저항` varchar(1) NOT NULL,
  `item_파괴저항` varchar(1) NOT NULL,
  `item_기준가격` varchar(1) NOT NULL,
  `item_처분가격` varchar(1) NOT NULL,
  `item_튜닝가격` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(1) NOT NULL,
  `item_효과코드_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(1) NOT NULL,
  `item_효과코드_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(1) NOT NULL,
  `item_효과코드_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_shoeitem`
--

CREATE TABLE IF NOT EXISTS `server_item_shoeitem` (
  `name_Korea` varchar(16) NOT NULL,
  `name_Japan` varchar(19) NOT NULL,
  `name_English` varchar(36) NOT NULL,
  `name_German` varchar(36) NOT NULL,
  `name_Italian` varchar(36) NOT NULL,
  `name_Spanish` varchar(36) NOT NULL,
  `name_Portuguese` varchar(36) NOT NULL,
  `name_French` varchar(36) NOT NULL,
  `name_Turkish` varchar(36) NOT NULL,
  `name_China` varchar(36) NOT NULL,
  `name_Taiwan` varchar(36) NOT NULL,
  `name_Indonesia` varchar(36) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(16) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_업그레이드코드` varchar(9) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(1) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(1) NOT NULL,
  `item_최대내구도` varchar(6) NOT NULL,
  `item_최소물공력` varchar(1) NOT NULL,
  `item_최대물공력` varchar(1) NOT NULL,
  `item_최소마공력` varchar(1) NOT NULL,
  `item_최대마공력` varchar(1) NOT NULL,
  `item_물방력` varchar(3) NOT NULL,
  `item_물공쿨타임밀초` varchar(1) NOT NULL,
  `item_물공최소거리` varchar(1) NOT NULL,
  `item_물공최대거리` varchar(1) NOT NULL,
  `item_마공케스팅타임밀초` varchar(1) NOT NULL,
  `item_마항력` varchar(3) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_마공명` varchar(1) NOT NULL,
  `item_물공피` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_물공모션타임밀초1` varchar(1) NOT NULL,
  `item_물공모션타임밀초2` varchar(1) NOT NULL,
  `item_크리공격모션타임밀초` varchar(1) NOT NULL,
  `item_최대업글단계` varchar(2) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(9) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_skillbookitem`
--

CREATE TABLE IF NOT EXISTS `server_item_skillbookitem` (
  `name_Korea` varchar(16) NOT NULL,
  `name_Japan` varchar(18) NOT NULL,
  `name_English` varchar(43) NOT NULL,
  `name_German` varchar(43) NOT NULL,
  `name_Italian` varchar(43) NOT NULL,
  `name_Spanish` varchar(43) NOT NULL,
  `name_Portuguese` varchar(43) NOT NULL,
  `name_French` varchar(43) NOT NULL,
  `name_Turkish` varchar(43) NOT NULL,
  `name_China` varchar(33) NOT NULL,
  `name_Taiwan` varchar(34) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(16) NOT NULL,
  `item_대상코드` varchar(9) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_stdmaterialitem`
--

CREATE TABLE IF NOT EXISTS `server_item_stdmaterialitem` (
  `name_Korea` varchar(19) NOT NULL,
  `name_Japan` varchar(19) NOT NULL,
  `name_English` varchar(41) NOT NULL,
  `name_German` varchar(41) NOT NULL,
  `name_Italian` varchar(41) NOT NULL,
  `name_Spanish` varchar(41) NOT NULL,
  `name_Portuguese` varchar(41) NOT NULL,
  `name_French` varchar(41) NOT NULL,
  `name_Turkish` varchar(41) NOT NULL,
  `name_China` varchar(41) NOT NULL,
  `name_Taiwan` varchar(41) NOT NULL,
  `name_Indonesia` varchar(41) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(18) NOT NULL,
  `item_사용구분` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(4) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_tradematerialitem`
--

CREATE TABLE IF NOT EXISTS `server_item_tradematerialitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(9) NOT NULL,
  `name_English` varchar(9) NOT NULL,
  `name_German` varchar(9) NOT NULL,
  `name_Italian` varchar(9) NOT NULL,
  `name_Spanish` varchar(9) NOT NULL,
  `name_Portuguese` varchar(9) NOT NULL,
  `name_French` varchar(9) NOT NULL,
  `name_Turkish` varchar(9) NOT NULL,
  `name_China` varchar(9) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(9) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(9) NOT NULL,
  `item_사용구분` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(2) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_upgradehelpitem`
--

CREATE TABLE IF NOT EXISTS `server_item_upgradehelpitem` (
  `name_Korea` varchar(13) NOT NULL,
  `name_Japan` varchar(13) NOT NULL,
  `name_English` varchar(28) NOT NULL,
  `name_German` varchar(28) NOT NULL,
  `name_Italian` varchar(28) NOT NULL,
  `name_Spanish` varchar(28) NOT NULL,
  `name_Portuguese` varchar(28) NOT NULL,
  `name_French` varchar(28) NOT NULL,
  `name_Turkish` varchar(28) NOT NULL,
  `name_China` varchar(9) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(12) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_사용구분` varchar(1) NOT NULL,
  `item_아이템등급` varchar(1) NOT NULL,
  `item_성공확률연산자` varchar(1) NOT NULL,
  `item_성공확률보정` varchar(10) NOT NULL,
  `item_소실방지` varchar(1) NOT NULL,
  `item_초기화방지` varchar(1) NOT NULL,
  `item_부서짐방지` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(2) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_upgradematerialitem`
--

CREATE TABLE IF NOT EXISTS `server_item_upgradematerialitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(9) NOT NULL,
  `name_English` varchar(9) NOT NULL,
  `name_German` varchar(9) NOT NULL,
  `name_Italian` varchar(9) NOT NULL,
  `name_Spanish` varchar(9) NOT NULL,
  `name_Portuguese` varchar(9) NOT NULL,
  `name_French` varchar(9) NOT NULL,
  `name_Turkish` varchar(9) NOT NULL,
  `name_China` varchar(9) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(9) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(7) NOT NULL,
  `item_사용구분` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(3) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_upgrademustitem`
--

CREATE TABLE IF NOT EXISTS `server_item_upgrademustitem` (
  `name_Korea` varchar(10) NOT NULL,
  `name_Japan` varchar(8) NOT NULL,
  `name_English` varchar(30) NOT NULL,
  `name_German` varchar(30) NOT NULL,
  `name_Italian` varchar(30) NOT NULL,
  `name_Spanish` varchar(30) NOT NULL,
  `name_Portuguese` varchar(30) NOT NULL,
  `name_French` varchar(30) NOT NULL,
  `name_Turkish` varchar(30) NOT NULL,
  `name_China` varchar(7) NOT NULL,
  `name_Taiwan` varchar(8) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(10) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_사용구분` varchar(1) NOT NULL,
  `item_아이템등급` varchar(2) NOT NULL,
  `item_성공확률연산자` varchar(1) NOT NULL,
  `item_성공확률보정` varchar(1) NOT NULL,
  `item_소실방지` varchar(1) NOT NULL,
  `item_초기화방지` varchar(1) NOT NULL,
  `item_부서짐방지` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(2) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_upgradestoneitem`
--

CREATE TABLE IF NOT EXISTS `server_item_upgradestoneitem` (
  `name_Korea` varchar(15) NOT NULL,
  `name_Japan` varchar(5) NOT NULL,
  `name_English` varchar(27) NOT NULL,
  `name_German` varchar(27) NOT NULL,
  `name_Italian` varchar(27) NOT NULL,
  `name_Spanish` varchar(27) NOT NULL,
  `name_Portuguese` varchar(27) NOT NULL,
  `name_French` varchar(27) NOT NULL,
  `name_Turkish` varchar(27) NOT NULL,
  `name_China` varchar(7) NOT NULL,
  `name_Taiwan` varchar(10) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(15) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_사용구분` varchar(1) NOT NULL,
  `item_아이템등급` varchar(1) NOT NULL,
  `item_성공확률연산자` varchar(1) NOT NULL,
  `item_성공확률보정` varchar(10) NOT NULL,
  `item_소실방지` varchar(1) NOT NULL,
  `item_초기화방지` varchar(1) NOT NULL,
  `item_부서짐방지` varchar(1) NOT NULL,
  `item_판매가격` varchar(1) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_중복가능수` varchar(2) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_upperitem`
--

CREATE TABLE IF NOT EXISTS `server_item_upperitem` (
  `name_Korea` varchar(16) NOT NULL,
  `name_Japan` varchar(18) NOT NULL,
  `name_English` varchar(35) NOT NULL,
  `name_German` varchar(35) NOT NULL,
  `name_Italian` varchar(35) NOT NULL,
  `name_Spanish` varchar(35) NOT NULL,
  `name_Portuguese` varchar(35) NOT NULL,
  `name_French` varchar(35) NOT NULL,
  `name_Turkish` varchar(35) NOT NULL,
  `name_China` varchar(35) NOT NULL,
  `name_Taiwan` varchar(35) NOT NULL,
  `name_Indonesia` varchar(35) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(14) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(1) NOT NULL,
  `item_육상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_해상LV` smallint(6) NOT NULL DEFAULT '0',
  `item_STR` varchar(1) NOT NULL,
  `item_DEX` varchar(1) NOT NULL,
  `item_CON` varchar(1) NOT NULL,
  `item_INT` varchar(1) NOT NULL,
  `item_WIS` varchar(1) NOT NULL,
  `item_VOL` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_타입코드` varchar(1) NOT NULL,
  `item_업그레이드코드` varchar(9) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(1) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(1) NOT NULL,
  `item_최대내구도` varchar(6) NOT NULL,
  `item_최소물공력` varchar(1) NOT NULL,
  `item_최대물공력` varchar(1) NOT NULL,
  `item_최소마공력` varchar(1) NOT NULL,
  `item_최대마공력` varchar(1) NOT NULL,
  `item_물방력` varchar(3) NOT NULL,
  `item_물공쿨타임밀초` varchar(1) NOT NULL,
  `item_물공최소거리` varchar(1) NOT NULL,
  `item_물공최대거리` varchar(1) NOT NULL,
  `item_마공케스팅타임밀초` varchar(1) NOT NULL,
  `item_마항력` varchar(3) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_마공명` varchar(1) NOT NULL,
  `item_물공피` varchar(1) NOT NULL,
  `item_크리티컬` varchar(1) NOT NULL,
  `item_물공모션타임밀초1` varchar(1) NOT NULL,
  `item_물공모션타임밀초2` varchar(1) NOT NULL,
  `item_크리공격모션타임밀초` varchar(1) NOT NULL,
  `item_최대업글단계` varchar(2) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(10) NOT NULL,
  `item_처분가격` varchar(10) NOT NULL,
  `item_폐기물코드` varchar(1) NOT NULL,
  `item_폐기물수량` varchar(1) NOT NULL,
  `item_효과코드_1` varchar(10) NOT NULL,
  `item_수치연산자_1` varchar(1) NOT NULL,
  `item_효과값_1` varchar(10) NOT NULL,
  `item_효과코드_2` varchar(10) NOT NULL,
  `item_수치연산자_2` varchar(1) NOT NULL,
  `item_효과값_2` varchar(10) NOT NULL,
  `item_효과코드_3` varchar(10) NOT NULL,
  `item_수치연산자_3` varchar(1) NOT NULL,
  `item_효과값_3` varchar(10) NOT NULL,
  `item_효과코드_4` varchar(10) NOT NULL,
  `item_수치연산자_4` varchar(1) NOT NULL,
  `item_효과값_4` varchar(1) NOT NULL,
  `item_효과코드_5` varchar(10) NOT NULL,
  `item_수치연산자_5` varchar(1) NOT NULL,
  `item_효과값_5` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  `item_개인상점거래가능` varchar(1) NOT NULL,
  `item_기간제타임` varchar(10) NOT NULL,
  `item_귀속상태` varchar(1) NOT NULL,
  `item_세트코드` varchar(9) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_item_weaponitem`
--

CREATE TABLE IF NOT EXISTS `server_item_weaponitem` (
  `name_Korea` varchar(9) NOT NULL,
  `name_Japan` varchar(9) NOT NULL,
  `name_English` varchar(9) NOT NULL,
  `name_German` varchar(9) NOT NULL,
  `name_Italian` varchar(9) NOT NULL,
  `name_Spanish` varchar(9) NOT NULL,
  `name_Portuguese` varchar(9) NOT NULL,
  `name_French` varchar(9) NOT NULL,
  `name_Turkish` varchar(9) NOT NULL,
  `name_China` varchar(9) NOT NULL,
  `name_Taiwan` varchar(9) NOT NULL,
  `name_Indonesia` varchar(9) NOT NULL,
  `item_코드` varchar(9) NOT NULL,
  `item_이름` varchar(13) NOT NULL,
  `item_사용성별` varchar(10) NOT NULL,
  `item_사용직업` varchar(4) NOT NULL,
  `item_착용등급` varchar(1) NOT NULL,
  `item_가치` varchar(1) NOT NULL,
  `item_장착파트` varchar(1) NOT NULL,
  `item_무기타입` varchar(1) NOT NULL,
  `item_상의타입` varchar(10) NOT NULL,
  `item_양손사용` varchar(1) NOT NULL,
  `item_탄타입` varchar(10) NOT NULL,
  `item_물공력` varchar(3) NOT NULL,
  `item_물방력` varchar(10) NOT NULL,
  `item_물공쿨타임밀초` varchar(3) NOT NULL,
  `item_물공거리` varchar(3) NOT NULL,
  `item_마항력` varchar(10) NOT NULL,
  `item_물공명` varchar(1) NOT NULL,
  `item_물공피` varchar(10) NOT NULL,
  `item_크리티컬` varchar(10) NOT NULL,
  `item_물공모션타임밀초` varchar(3) NOT NULL,
  `item_최대업글단계` varchar(1) NOT NULL,
  `item_탄소모량` varchar(1) NOT NULL,
  `item_정령탄소모량` varchar(1) NOT NULL,
  `item_중복가능수` varchar(1) NOT NULL,
  `item_퀘스트용` varchar(1) NOT NULL,
  `item_판매가격` varchar(3) NOT NULL,
  `item_처분가격` varchar(3) NOT NULL,
  `item_효과코드_1st` varchar(10) NOT NULL,
  `item_효과값_1st` varchar(1) NOT NULL,
  `item_효과코드_2nd` varchar(10) NOT NULL,
  `item_효과값_2nd` varchar(1) NOT NULL,
  `item_효과코드_3rd` varchar(10) NOT NULL,
  `item_효과값_3rd` varchar(1) NOT NULL,
  `item_매매가능` varchar(1) NOT NULL,
  `item_버림가능` varchar(1) NOT NULL,
  `item_교환가능` varchar(1) NOT NULL,
  `item_보관가능` varchar(1) NOT NULL,
  PRIMARY KEY (`item_코드`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_map`
--

CREATE TABLE IF NOT EXISTS `server_map` (
  `mapid` varchar(20) NOT NULL,
  `parentmap` varchar(20) DEFAULT NULL,
  `mappicture` varchar(10) NOT NULL,
  `LTWH` varchar(50) NOT NULL,
  PRIMARY KEY (`mapid`),
  KEY `parentmap` (`parentmap`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_npc`
--

CREATE TABLE IF NOT EXISTS `server_npc` (
  `npc_picture` varchar(14) NOT NULL,
  `npc_bossfactor` smallint(6) NOT NULL,
  `name_Korea` varchar(15) NOT NULL,
  `name_Japan` varchar(18) NOT NULL,
  `name_English` varchar(39) NOT NULL,
  `name_German` varchar(39) NOT NULL,
  `name_Italian` varchar(39) NOT NULL,
  `name_Spanish` varchar(39) NOT NULL,
  `name_Portuguese` varchar(39) NOT NULL,
  `name_French` varchar(39) NOT NULL,
  `name_Turkish` varchar(39) NOT NULL,
  `name_China` varchar(17) NOT NULL,
  `name_Taiwan` varchar(26) NOT NULL,
  `name_Indonesia` varchar(1) NOT NULL,
  `npc_코드` varchar(9) NOT NULL,
  `npc_이름` varchar(19) NOT NULL,
  `npc_직업` varchar(1) NOT NULL,
  `npc_NPC직업` varchar(2) NOT NULL,
  `npc_몬스터등급타입` varchar(1) NOT NULL,
  `npc_무생물` varchar(1) NOT NULL,
  `npc_필드구분` varchar(1) NOT NULL,
  `npc_함선형` varchar(1) NOT NULL,
  `npc_공중유닛` varchar(1) NOT NULL,
  `npc_테이밍` varchar(1) NOT NULL,
  `npc_기준레벨` int(11) NOT NULL,
  `npc_보상경험치` int(11) NOT NULL,
  `npc_보상SP` varchar(2) NOT NULL,
  `npc_몸가로길이` varchar(4) NOT NULL,
  `npc_몸세로길이` varchar(4) NOT NULL,
  `npc_기준최대HP` varchar(7) NOT NULL,
  `npc_회복속도` varchar(10) NOT NULL,
  `npc_최소물공력` varchar(4) NOT NULL,
  `npc_최대물공력` varchar(4) NOT NULL,
  `npc_최소마공력` varchar(3) NOT NULL,
  `npc_최대마공력` varchar(4) NOT NULL,
  `npc_물방력` varchar(5) NOT NULL,
  `npc_마항력` varchar(4) NOT NULL,
  `npc_물공피` varchar(10) NOT NULL,
  `npc_물공명` varchar(5) NOT NULL,
  `npc_마공명` varchar(5) NOT NULL,
  `npc_크리성공` varchar(4) NOT NULL,
  `npc_크리저항` varchar(5) NOT NULL,
  `npc_물리공격범위` varchar(4) NOT NULL,
  `npc_몹함포갯수` varchar(1) NOT NULL,
  `npc_몹함포속도` varchar(4) NOT NULL,
  `npc_몹함포집탄범위` varchar(3) NOT NULL,
  `npc_물리공격캐스팅타임밀초` varchar(2) NOT NULL,
  `npc_물리공격쿨타임밀초` varchar(4) NOT NULL,
  `npc_물리공격모션타임밀초1` varchar(4) NOT NULL,
  `npc_물리공격모션타임밀초2` varchar(4) NOT NULL,
  `npc_크리공격모션타임밀초` varchar(4) NOT NULL,
  `npc_죽는모션타임밀초` varchar(5) NOT NULL,
  `npc_죽는모션밀림구분` varchar(1) NOT NULL,
  `npc_소멸지연타임밀초` varchar(5) NOT NULL,
  `npc_선공시야` varchar(4) NOT NULL,
  `npc_반응시야` varchar(5) NOT NULL,
  `npc_요청시야` varchar(5) NOT NULL,
  `npc_귀환시야` varchar(5) NOT NULL,
  `npc_최소사거리제한` varchar(3) NOT NULL,
  `npc_기본사정거리` varchar(4) NOT NULL,
  `npc_공격거리타입` varchar(1) NOT NULL,
  `npc_걷기속도` varchar(10) NOT NULL,
  `npc_뛰기속도` varchar(10) NOT NULL,
  `npc_선회력` varchar(3) NOT NULL,
  `npc_평상이동지연시간초` varchar(3) NOT NULL,
  `npc_평상이동단위` varchar(10) NOT NULL,
  `npc_오브젝트채팅` varchar(9) NOT NULL,
  `npc_부가Action1코드` varchar(9) NOT NULL,
  `npc_부가Action1선택율` varchar(5) NOT NULL,
  `npc_부가Action2코드` varchar(9) NOT NULL,
  `npc_부가Action2선택율` varchar(4) NOT NULL,
  `npc_원소공격력` varchar(1) NOT NULL,
  `npc_원소저항력` varchar(1) NOT NULL,
  `npc_환영공격력` varchar(1) NOT NULL,
  `npc_환영저항력` varchar(1) NOT NULL,
  `npc_신성공격력` varchar(1) NOT NULL,
  `npc_신성저항력` varchar(1) NOT NULL,
  `npc_암흑공격력` varchar(1) NOT NULL,
  `npc_암흑저항력` varchar(1) NOT NULL,
  `npc_물리속성공격력` varchar(1) NOT NULL,
  `npc_물리속성저항력` varchar(4) NOT NULL,
  `npc_독속성공격력` varchar(1) NOT NULL,
  `npc_독속성저항력` varchar(4) NOT NULL,
  `npc_화염속성공격력` varchar(1) NOT NULL,
  `npc_화염속성저항력` varchar(10) NOT NULL,
  `npc_냉기속성공격력` varchar(1) NOT NULL,
  `npc_냉기속성저항력` varchar(4) NOT NULL,
  `npc_전격속성공격력` varchar(1) NOT NULL,
  `npc_전격속성저항력` varchar(4) NOT NULL,
  `npc_신성속성공격력` varchar(1) NOT NULL,
  `npc_신성속성저항력` varchar(10) NOT NULL,
  `npc_암흑속성공격력` varchar(1) NOT NULL,
  `npc_암흑속성저항력` varchar(4) NOT NULL,
  `npc_절대속성공격력` varchar(4) NOT NULL,
  `npc_절대속성저항력` varchar(4) NOT NULL,
  `npc_file` varchar(12) NOT NULL,
  PRIMARY KEY (`npc_코드`),
  KEY `npc_기준레벨` (`npc_기준레벨`),
  KEY `npc_보상경험치` (`npc_보상경험치`),
  KEY `npc_file` (`npc_file`),
  FULLTEXT KEY `name_Korea` (`name_Korea`),
  FULLTEXT KEY `name_Japan` (`name_Japan`),
  FULLTEXT KEY `name_English` (`name_English`),
  FULLTEXT KEY `name_German` (`name_German`),
  FULLTEXT KEY `name_Italian` (`name_Italian`),
  FULLTEXT KEY `name_Spanish` (`name_Spanish`),
  FULLTEXT KEY `name_Portuguese` (`name_Portuguese`),
  FULLTEXT KEY `name_French` (`name_French`),
  FULLTEXT KEY `name_Turkish` (`name_Turkish`),
  FULLTEXT KEY `name_China` (`name_China`),
  FULLTEXT KEY `name_Taiwan` (`name_Taiwan`),
  FULLTEXT KEY `name_Indonesia` (`name_Indonesia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_questlist`
--

CREATE TABLE IF NOT EXISTS `server_questlist` (
  `questlistid` varchar(16) NOT NULL,
  `questlistxml` text NOT NULL,
  `questtype` char(1) NOT NULL DEFAULT 'l',
  `questsourcenpc` varchar(32) NOT NULL,
  `questsourcemap` varchar(32) NOT NULL,
  `questlevel` smallint(5) unsigned NOT NULL,
  `questclasses` varchar(32) NOT NULL,
  `privquest` varchar(16) NOT NULL,
  `nextquest` varchar(16) NOT NULL,
  `questtitle_EN` text NOT NULL,
  `questtitle_ESP` text NOT NULL,
  `questtitle_FR` text NOT NULL,
  `questtitle_GER` text NOT NULL,
  `questtitle_IT` text NOT NULL,
  `questtitle_PT` text NOT NULL,
  `questtitle_TR` text NOT NULL,
  `questtitle_KR` text NOT NULL,
  `questtitle_CN` text NOT NULL,
  `questtitle_JP` text NOT NULL,
  `questtitle_TW` text NOT NULL,
  PRIMARY KEY (`questlistid`),
  KEY `questlevel` (`questlevel`),
  KEY `questsourcenpc` (`questsourcenpc`),
  KEY `questsourcemap` (`questsourcemap`),
  KEY `privquest` (`privquest`),
  KEY `nextquest` (`nextquest`),
  KEY `questtype` (`questtype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_questreferences`
--

CREATE TABLE IF NOT EXISTS `server_questreferences` (
  `refid` varchar(9) NOT NULL,
  `questid` varchar(9) NOT NULL,
  PRIMARY KEY (`refid`,`questid`),
  KEY `questid` (`questid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_questtext_CN`
--

CREATE TABLE IF NOT EXISTS `server_questtext_CN` (
  `questlistid` varchar(255) CHARACTER SET utf8 NOT NULL,
  `questtextxml` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`questlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `server_questtext_EN`
--

CREATE TABLE IF NOT EXISTS `server_questtext_EN` (
  `questlistid` varchar(255) NOT NULL,
  `questtextxml` text NOT NULL,
  PRIMARY KEY (`questlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_questtext_ESP`
--

CREATE TABLE IF NOT EXISTS `server_questtext_ESP` (
  `questlistid` varchar(255) NOT NULL,
  `questtextxml` text NOT NULL,
  PRIMARY KEY (`questlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_questtext_FR`
--

CREATE TABLE IF NOT EXISTS `server_questtext_FR` (
  `questlistid` varchar(255) NOT NULL,
  `questtextxml` text NOT NULL,
  PRIMARY KEY (`questlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_questtext_GER`
--

CREATE TABLE IF NOT EXISTS `server_questtext_GER` (
  `questlistid` varchar(255) NOT NULL,
  `questtextxml` text NOT NULL,
  PRIMARY KEY (`questlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_questtext_IT`
--

CREATE TABLE IF NOT EXISTS `server_questtext_IT` (
  `questlistid` varchar(255) NOT NULL,
  `questtextxml` text NOT NULL,
  PRIMARY KEY (`questlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_questtext_JP`
--

CREATE TABLE IF NOT EXISTS `server_questtext_JP` (
  `questlistid` varchar(255) CHARACTER SET utf8 NOT NULL,
  `questtextxml` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`questlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `server_questtext_KR`
--

CREATE TABLE IF NOT EXISTS `server_questtext_KR` (
  `questlistid` varchar(255) NOT NULL,
  `questtextxml` text NOT NULL,
  PRIMARY KEY (`questlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_questtext_PT`
--

CREATE TABLE IF NOT EXISTS `server_questtext_PT` (
  `questlistid` varchar(255) NOT NULL,
  `questtextxml` text NOT NULL,
  PRIMARY KEY (`questlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_questtext_TR`
--

CREATE TABLE IF NOT EXISTS `server_questtext_TR` (
  `questlistid` varchar(255) NOT NULL,
  `questtextxml` text NOT NULL,
  PRIMARY KEY (`questlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_questtext_TW`
--

CREATE TABLE IF NOT EXISTS `server_questtext_TW` (
  `questlistid` varchar(255) CHARACTER SET utf8 NOT NULL,
  `questtextxml` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`questlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `server_seal_breakcost`
--

CREATE TABLE IF NOT EXISTS `server_seal_breakcost` (
  `costid` varchar(6) NOT NULL,
  `itemlevel` smallint(6) NOT NULL DEFAULT '0',
  `cost` smallint(6) NOT NULL DEFAULT '0',
  `needitem1` varchar(9) NOT NULL,
  `needitem1count` smallint(6) NOT NULL DEFAULT '0',
  `needitem2` varchar(1) NOT NULL,
  `needitem2count` smallint(6) NOT NULL DEFAULT '0',
  `needitem3` varchar(1) NOT NULL,
  `needitem3count` smallint(6) NOT NULL DEFAULT '0',
  `needitem4` varchar(1) NOT NULL,
  `needitem4count` smallint(6) NOT NULL DEFAULT '0',
  `needitem5` varchar(1) NOT NULL,
  `needitem5count` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`costid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_seal_option`
--

CREATE TABLE IF NOT EXISTS `server_seal_option` (
  `sealid` varchar(5) NOT NULL,
  `sealoption` text NOT NULL,
  PRIMARY KEY (`sealid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_skill`
--

CREATE TABLE IF NOT EXISTS `server_skill` (
  `skill_picture` varchar(7) NOT NULL,
  `skill_코드` varchar(9) NOT NULL,
  `skill_이름` varchar(19) NOT NULL,
  `skill_UI분류` varchar(1) NOT NULL,
  `skill_효과발동구분` varchar(1) NOT NULL,
  `skill_계열` varchar(1) NOT NULL,
  `skill_원형코드` varchar(9) NOT NULL,
  `skill_레벨` smallint(6) NOT NULL DEFAULT '0',
  `skill_마스터레벨` varchar(2) NOT NULL,
  `skill_사용직업1` varchar(5) NOT NULL,
  `skill_사용직업2` varchar(1) NOT NULL,
  `skill_습득가능레벨_육전` varchar(10) NOT NULL,
  `skill_습득가능레벨_해전` varchar(10) NOT NULL,
  `skill_습득소모SP` varchar(1) NOT NULL,
  `skill_필요스킬코드1` varchar(9) NOT NULL,
  `skill_필요스킬코드2` varchar(8) NOT NULL,
  `skill_필요스킬코드3` varchar(1) NOT NULL,
  `skill_필요스킬코드4` varchar(1) NOT NULL,
  `skill_필요스킬코드5` varchar(1) NOT NULL,
  `skill_소모ACT` varchar(4) NOT NULL,
  `skill_사용대상` varchar(2) NOT NULL,
  `skill_사용가능무기타입` varchar(3) NOT NULL,
  `skill_시전유효최소거리` varchar(5) NOT NULL,
  `skill_시전유효최대거리` varchar(10) NOT NULL,
  `skill_쿨타임밀초` varchar(10) NOT NULL,
  `skill_포탄속도` varchar(4) NOT NULL,
  `skill_캐스팅시간밀초` varchar(10) NOT NULL,
  `skill_모션타임밀초` varchar(10) NOT NULL,
  `skill_발포회수` varchar(10) NOT NULL,
  `skill_공격모션횟수` varchar(10) NOT NULL,
  `skill_명중률` varchar(3) NOT NULL,
  `skill_명중보정` varchar(2) NOT NULL,
  `skill_데쉬거리` varchar(10) NOT NULL,
  `skill_푸쉬거리` varchar(4) NOT NULL,
  `skill_자동공격여부` varchar(1) NOT NULL,
  `skill_타겟지정방식` varchar(1) NOT NULL,
  `skill_타겟제한수` varchar(1) NOT NULL,
  `skill_영향범위` varchar(10) NOT NULL,
  `skill_영향각도` varchar(3) NOT NULL,
  `skill_일시코드1` varchar(10) NOT NULL,
  `skill_일시수치연산자1` varchar(1) NOT NULL,
  `skill_일시값1` varchar(10) NOT NULL,
  `skill_지능보정1_1` varchar(10) NOT NULL,
  `skill_지능보정2_1` varchar(10) NOT NULL,
  `skill_일시코드2` varchar(10) NOT NULL,
  `skill_일시수치연산자2` varchar(1) NOT NULL,
  `skill_일시값2` varchar(10) NOT NULL,
  `skill_지능보정1_2` varchar(1) NOT NULL,
  `skill_지능보정2_2` varchar(1) NOT NULL,
  `skill_적용시간밀리초` varchar(7) NOT NULL,
  `skill_지속코드1` varchar(10) NOT NULL,
  `skill_지속수치연산자1` varchar(1) NOT NULL,
  `skill_지속값1` varchar(10) NOT NULL,
  `skill_지속코드2` varchar(10) NOT NULL,
  `skill_지속수치연산자2` varchar(1) NOT NULL,
  `skill_지속값2` varchar(10) NOT NULL,
  `skill_지속코드3` varchar(10) NOT NULL,
  `skill_지속수치연산자3` varchar(1) NOT NULL,
  `skill_지속값3` varchar(10) NOT NULL,
  `skill_지속코드4` varchar(10) NOT NULL,
  `skill_지속수치연산자4` varchar(1) NOT NULL,
  `skill_지속값4` varchar(10) NOT NULL,
  `skill_지속사망후유지` varchar(1) NOT NULL,
  `skill_토글주기밀리초` varchar(4) NOT NULL,
  `skill_토글지속소모량연산자` varchar(1) NOT NULL,
  `skill_토글지속필요HP` varchar(1) NOT NULL,
  `skill_토글지속필요MP` varchar(10) NOT NULL,
  `skill_패시브코드1` varchar(10) NOT NULL,
  `skill_패시브수치연산자1` varchar(1) NOT NULL,
  `skill_패시브값1` varchar(10) NOT NULL,
  `skill_패시브코드2` varchar(10) NOT NULL,
  `skill_패시브수치연산자2` varchar(1) NOT NULL,
  `skill_패시브값2` varchar(10) NOT NULL,
  `skill_패시브코드3` varchar(10) NOT NULL,
  `skill_패시브수치연산자3` varchar(1) NOT NULL,
  `skill_패시브값3` varchar(1) NOT NULL,
  `skill_속성공격력1` varchar(1) NOT NULL,
  `skill_속성저항력1` varchar(1) NOT NULL,
  `skill_속성공격력2` varchar(1) NOT NULL,
  `skill_속성저항력2` varchar(1) NOT NULL,
  `skill_속성공격력3` varchar(1) NOT NULL,
  `skill_속성저항력3` varchar(1) NOT NULL,
  `skill_속성공격력4` varchar(1) NOT NULL,
  `skill_속성저항력4` varchar(1) NOT NULL,
  `skill_대응일시효과코드` varchar(10) NOT NULL,
  `skill_대응일시효과수치` varchar(10) NOT NULL,
  `skill_대응지속효과코드` varchar(10) NOT NULL,
  `skill_대응지속효과수치` varchar(10) NOT NULL,
  `skill_어그로수치` varchar(3) NOT NULL,
  `skill_속성코드` varchar(1) NOT NULL,
  `skill_속성값` varchar(10) NOT NULL,
  PRIMARY KEY (`skill_코드`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_skilltrees`
--

CREATE TABLE IF NOT EXISTS `server_skilltrees` (
  `skilltreeid` varchar(64) NOT NULL,
  `xmltree` text NOT NULL,
  `rectinfostart` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`skilltreeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_storelist`
--

CREATE TABLE IF NOT EXISTS `server_storelist` (
  `npcid` varchar(9) NOT NULL,
  `itemid` varchar(9) NOT NULL,
  PRIMARY KEY (`npcid`,`itemid`),
  KEY `itemid` (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_stringtable`
--

CREATE TABLE IF NOT EXISTS `server_stringtable` (
  `Code` varchar(9) NOT NULL,
  `Korea` varchar(28) NOT NULL,
  `Japan` varchar(37) NOT NULL,
  `English` varchar(73) NOT NULL,
  `German` varchar(111) NOT NULL,
  `Italian` varchar(78) NOT NULL,
  `Spanish` varchar(73) NOT NULL,
  `Portuguese` varchar(70) NOT NULL,
  `French` varchar(72) NOT NULL,
  `Turkish` varchar(118) NOT NULL,
  `China` varchar(43) NOT NULL,
  `Taiwan` varchar(62) NOT NULL,
  `Indonesia` varchar(73) NOT NULL,
  PRIMARY KEY (`Code`),
  FULLTEXT KEY `Korea` (`Korea`),
  FULLTEXT KEY `Japan` (`Japan`),
  FULLTEXT KEY `English` (`English`),
  FULLTEXT KEY `German` (`German`),
  FULLTEXT KEY `Italian` (`Italian`),
  FULLTEXT KEY `Spanish` (`Spanish`),
  FULLTEXT KEY `Portuguese` (`Portuguese`),
  FULLTEXT KEY `French` (`French`),
  FULLTEXT KEY `Turkish` (`Turkish`),
  FULLTEXT KEY `China` (`China`),
  FULLTEXT KEY `Taiwan` (`Taiwan`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server_upgraderule`
--

CREATE TABLE IF NOT EXISTS `server_upgraderule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_upgraderule_코드` varchar(9) NOT NULL,
  `server_upgraderule_이름` varchar(20) NOT NULL,
  `server_upgraderule_업그레이드레벨` varchar(2) NOT NULL,
  `server_upgraderule_효과코드0` varchar(3) NOT NULL,
  `server_upgraderule_연산자0` varchar(1) NOT NULL,
  `server_upgraderule_효과값0` varchar(10) NOT NULL,
  `server_upgraderule_효과코드1` varchar(10) NOT NULL,
  `server_upgraderule_연산자1` varchar(1) NOT NULL,
  `server_upgraderule_효과값1` varchar(10) NOT NULL,
  `server_upgraderule_효과코드2` varchar(10) NOT NULL,
  `server_upgraderule_연산자2` varchar(1) NOT NULL,
  `server_upgraderule_효과값2` varchar(10) NOT NULL,
  `server_upgraderule_효과코드3` varchar(10) NOT NULL,
  `server_upgraderule_연산자3` varchar(1) NOT NULL,
  `server_upgraderule_효과값3` varchar(10) NOT NULL,
  `server_upgraderule_강화소모gelt` varchar(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4401 ;
